package com.example.bookmanagmentsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmanagmentsystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
