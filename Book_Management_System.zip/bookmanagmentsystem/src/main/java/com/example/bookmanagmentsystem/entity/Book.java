package com.example.bookmanagmentsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("book")
public class Book {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String bookName;

    private String author;

    private String publisher;

    private String isbn;

    private LocalDate publishDate;

    private Long categoryId;

    private String coverImage;

    private String introduction;

    private Integer totalStock;

    private Integer availableStock;

    private BigDecimal price;

    private LocalDateTime createTime;

}
