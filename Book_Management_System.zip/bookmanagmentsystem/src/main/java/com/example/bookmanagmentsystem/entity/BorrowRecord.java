package com.example.bookmanagmentsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("borrow_record")
public class BorrowRecord {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long readerId;
    
    private Long bookId;
    
    private LocalDateTime borrowTime;
    
    private LocalDateTime dueTime;
    
    private LocalDateTime returnTime;
    
    private LocalDateTime expectedReturnTime;
    
    private Integer renewCount;
    
    private Integer overdueDays;
    
    private BigDecimal fineAmount;
    
    private Integer status;
}
