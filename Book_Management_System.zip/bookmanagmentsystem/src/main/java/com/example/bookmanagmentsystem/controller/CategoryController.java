package com.example.bookmanagmentsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.BookCategory;
import com.example.bookmanagmentsystem.mapper.BookCategoryMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final BookCategoryMapper categoryMapper;

    @GetMapping
    public Result<List<BookCategory>> getAllCategories() {
        List<BookCategory> categories = categoryMapper.selectList(
                new LambdaQueryWrapper<BookCategory>()
                        .orderByAsc(BookCategory::getSortOrder)
        );
        return Result.success(categories);
    }
}
