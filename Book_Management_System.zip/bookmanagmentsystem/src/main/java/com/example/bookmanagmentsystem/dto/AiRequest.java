package com.example.bookmanagmentsystem.dto;

import lombok.Data;

@Data
public class AiRequest {

    private String message;

    private Long userId;

    private String role;
}
