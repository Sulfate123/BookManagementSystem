package com.example.bookmanagmentsystem.dto;

import lombok.Data;

@Data
public class AiResponse {

    private String reply;

    private Integer code;

    private String action;

    private Object data;

    private Boolean streaming;
}
