package com.example.bookmanagmentsystem.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 配置上传文件的访问路径
        registry.addResourceHandler("/uploads/avatars/**")
                .addResourceLocations("file:./uploads/avatars/");

        // 配置 images 目录访问路径
        registry.addResourceHandler("/images/**")
                .addResourceLocations("classpath:/static/images/");
    }
}