package com.example.bookmanagmentsystem.controller;

import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.dto.BorrowRecordVO;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.service.BorrowService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/borrow")
@RequiredArgsConstructor
public class BorrowController {
    
    private final BorrowService borrowService;
    
    @PostMapping
    public Result<String> borrowBook(@RequestBody Map<String, Object> data) {
        if (data.containsKey("expectedReturnTime")) {
            return borrowService.borrowBookWithExpectedTime(data);
        } else {
            return borrowService.borrowBook(
                Long.valueOf(data.get("readerId").toString()),
                Long.valueOf(data.get("bookId").toString())
            );
        }
    }
    
    @PostMapping("/return/{recordId}")
    public Result<String> returnBook(@PathVariable Long recordId) {
        return borrowService.returnBook(recordId);
    }
    
    @PostMapping("/renew/{recordId}")
    public Result<String> renewBook(@PathVariable Long recordId) {
        return borrowService.renewBook(recordId);
    }
    
    @GetMapping("/reader/{readerId}")
    public Result<List<BorrowRecordVO>> getReaderBorrowRecords(@PathVariable Long readerId) {
        return borrowService.getBorrowRecordsByReaderId(readerId);
    }
    
    @GetMapping("/all")
    public Result<List<BorrowRecordVO>> getAllBorrowRecords() {
        return borrowService.getAllBorrowRecordsWithDetails();
    }
    
    @GetMapping("/overdue")
    public Result<List<BorrowRecord>> getOverdueRecords() {
        return borrowService.getOverdueRecords();
    }
}
