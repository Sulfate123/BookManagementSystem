package com.example.bookmanagmentsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.Book;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.mapper.BookMapper;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import com.example.bookmanagmentsystem.mapper.ReaderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final BookMapper bookMapper;
    private final ReaderMapper readerMapper;
    private final BorrowRecordMapper borrowRecordMapper;

    @GetMapping
    public Result<Map<String, Object>> getStatistics() {
        Map<String, Object> stats = new HashMap<>();

        // 获取所有图书
        List<Book> allBooks = bookMapper.selectList(null);
        
        // 总图书数 = 所有图书的总库存（总册数）
        long totalBooks = allBooks.stream()
                .mapToLong(book -> book.getTotalStock() != null ? book.getTotalStock() : 0)
                .sum();
        stats.put("totalBooks", totalBooks);

        // 在馆图书 = 所有图书的可用库存总和
        long availableBooks = allBooks.stream()
                .mapToLong(book -> book.getAvailableStock() != null ? book.getAvailableStock() : 0)
                .sum();
        stats.put("availableBooks", availableBooks);

        // 借出图书 = 当前正在借阅中的记录数
        long borrowedBooks = borrowRecordMapper.selectCount(
                new LambdaQueryWrapper<BorrowRecord>()
                        .eq(BorrowRecord::getStatus, 0)
        );
        stats.put("borrowedBooks", borrowedBooks);

        long totalReaders = readerMapper.selectCount(null);
        stats.put("totalReaders", totalReaders);

        long totalBorrows = borrowRecordMapper.selectCount(null);
        stats.put("totalBorrows", totalBorrows);

        long overdueCount = borrowRecordMapper.selectCount(
                new LambdaQueryWrapper<BorrowRecord>()
                        .eq(BorrowRecord::getStatus, 0)
                        .lt(BorrowRecord::getDueTime, LocalDateTime.now())
        );
        stats.put("overdueCount", overdueCount);

        return Result.success(stats);
    }
}
