package com.example.bookmanagmentsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.common.IsbnValidator;
import com.example.bookmanagmentsystem.entity.Book;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.mapper.BookMapper;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import com.example.bookmanagmentsystem.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;
    
    private final BookMapper bookMapper;
    
    private final BorrowRecordMapper borrowRecordMapper;

    @GetMapping
    public Result<Page<Book>> getBookList(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId) {
        return bookService.getBookList(pageNum, pageSize, keyword, categoryId);
    }

    @GetMapping("/{id}")
    public Result<Book> getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }
    
    @GetMapping("/all")
    public Result<List<Book>> getAllBooks() {
        List<Book> books = bookMapper.selectList(
            new LambdaQueryWrapper<Book>()
                .orderByDesc(Book::getCreateTime)
        );
        return Result.success(books);
    }

    @PostMapping
    public Result<String> addBook(@RequestBody Book book) {
        IsbnValidator.ValidationResult validation = IsbnValidator.validate(book.getIsbn());
        if (!validation.isValid()) {
            return Result.error(validation.getErrorMessage());
        }
        
        int maxStock = 9999999;
        if (book.getTotalStock() < 0) {
            return Result.error("库存不能为负数");
        }
        if (book.getTotalStock() > maxStock) {
            return Result.error("库存不能超过" + maxStock);
        }
        
        book.setAvailableStock(book.getTotalStock());
        book.setCreateTime(java.time.LocalDateTime.now());
        bookMapper.insert(book);
        return Result.success("添加成功");
    }

    @PutMapping
    public Result<String> updateBook(@RequestBody Book book) {
        Book existingBook = bookMapper.selectById(book.getId());
        if (existingBook == null) {
            return Result.error("图书不存在");
        }
        
        IsbnValidator.ValidationResult validation = IsbnValidator.validate(book.getIsbn());
        if (!validation.isValid()) {
            return Result.error(validation.getErrorMessage());
        }
        
        int maxStock = 9999999;
        if (book.getTotalStock() < 0) {
            return Result.error("库存不能为负数");
        }
        if (book.getTotalStock() > maxStock) {
            return Result.error("库存不能超过" + maxStock);
        }
        
        int stockDiff = book.getTotalStock() - existingBook.getTotalStock();
        
        existingBook.setBookName(book.getBookName());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setPublisher(book.getPublisher());
        existingBook.setIsbn(book.getIsbn());
        existingBook.setPublishDate(book.getPublishDate());
        existingBook.setCategoryId(book.getCategoryId());
        existingBook.setCoverImage(book.getCoverImage());
        existingBook.setIntroduction(book.getIntroduction());
        existingBook.setPrice(book.getPrice());
        existingBook.setTotalStock(book.getTotalStock());
        existingBook.setAvailableStock(existingBook.getAvailableStock() + stockDiff);
        
        bookMapper.updateById(existingBook);
        return Result.success("更新成功");
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteBook(@PathVariable Long id) {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getBookId, id)
                .and(w -> w.isNull(BorrowRecord::getReturnTime)
                        .or()
                        .eq(BorrowRecord::getStatus, 0)
                        .or()
                        .eq(BorrowRecord::getStatus, 2));
        
        long count = borrowRecordMapper.selectCount(wrapper);
        if (count > 0) {
            return Result.error("该书存在未归还记录，无法删除");
        }
        
        bookMapper.deleteById(id);
        return Result.success("删除成功");
    }

    @GetMapping("/hot")
    public Result<List<Book>> getHotBooks() {
        return bookService.getHotBooks();
    }

    @GetMapping("/new")
    public Result<List<Book>> getNewBooks() {
        return bookService.getNewBooks();
    }
}
