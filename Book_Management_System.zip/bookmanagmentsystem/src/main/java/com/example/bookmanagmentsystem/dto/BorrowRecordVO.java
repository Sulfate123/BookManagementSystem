package com.example.bookmanagmentsystem.dto;

import com.example.bookmanagmentsystem.entity.BorrowRecord;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class BorrowRecordVO {

    private Long id;

    private Long readerId;

    private String readerName;

    private Long bookId;

    private String bookName;

    private LocalDateTime borrowTime;

    private LocalDateTime dueTime;

    private LocalDateTime returnTime;

    private LocalDateTime expectedReturnTime;

    private Integer renewCount;

    private Integer overdueDays;

    private BigDecimal fineAmount;

    private Integer status;

    public BorrowRecordVO(BorrowRecord record) {
        this.id = record.getId();
        this.readerId = record.getReaderId();
        this.bookId = record.getBookId();
        this.borrowTime = record.getBorrowTime();
        this.dueTime = record.getDueTime();
        this.returnTime = record.getReturnTime();
        this.expectedReturnTime = record.getExpectedReturnTime();
        this.renewCount = record.getRenewCount();
        this.overdueDays = record.getOverdueDays();
        this.fineAmount = record.getFineAmount();
        this.status = record.getStatus();
    }
}
