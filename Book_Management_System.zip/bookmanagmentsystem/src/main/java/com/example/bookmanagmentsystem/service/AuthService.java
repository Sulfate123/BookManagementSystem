package com.example.bookmanagmentsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.config.JwtUtil;
import com.example.bookmanagmentsystem.entity.Admin;
import com.example.bookmanagmentsystem.entity.Reader;
import com.example.bookmanagmentsystem.mapper.AdminMapper;
import com.example.bookmanagmentsystem.mapper.ReaderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AdminMapper adminMapper;

    private final ReaderMapper readerMapper;

    private final PasswordEncoder passwordEncoder;

    private final JwtUtil jwtUtil;

    public Result<Map<String, Object>> adminLogin(String username, String password) {
        System.out.println("=== 管理员登录尝试 ===");
        System.out.println("用户名: " + username);
        
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Admin::getUsername, username);
        Admin admin = adminMapper.selectOne(wrapper);

        if (admin == null) {
            System.out.println("错误: 用户不存在");
            return Result.error("用户名或密码错误");
        }

        System.out.println("找到用户，状态: " + admin.getStatus());
        
        if (admin.getStatus() == 0) {
            System.out.println("错误: 账号已被禁用");
            return Result.error("账号已被禁用");
        }

        System.out.println("数据库中的密码哈希: " + admin.getPassword());
        System.out.println("输入的密码: " + password);
        
        boolean matches = passwordEncoder.matches(password, admin.getPassword());
        System.out.println("密码匹配结果: " + matches);
        
        if (!matches) {
            return Result.error("用户名或密码错误");
        }

        String token = jwtUtil.generateToken(admin.getId(), admin.getUsername(), "admin");

        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userId", admin.getId());
        data.put("username", admin.getUsername());
        data.put("realName", admin.getRealName());
        data.put("role", "admin");

        System.out.println("登录成功！");
        return Result.success(data);
    }

    public Result<Map<String, Object>> readerLogin(String username, String password) {
        LambdaQueryWrapper<Reader> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Reader::getUsername, username);
        Reader reader = readerMapper.selectOne(wrapper);

        if (reader == null) {
            return Result.error("用户名或密码错误");
        }

        if (!passwordEncoder.matches(password, reader.getPassword())) {
            return Result.error("用户名或密码错误");
        }

        String token = jwtUtil.generateToken(reader.getId(), reader.getUsername(), "reader");

        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userId", reader.getId());
        data.put("username", reader.getUsername());
        data.put("realName", reader.getRealName());
        data.put("avatar", reader.getAvatar());
        data.put("role", "reader");

        return Result.success(data);
    }

    public Result<String> readerRegister(Reader reader) {
        LambdaQueryWrapper<Reader> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Reader::getUsername, reader.getUsername());
        if (readerMapper.selectCount(wrapper) > 0) {
            return Result.error("用户名已存在");
        }

        if (reader.getPhone() == null || reader.getPhone().trim().isEmpty()) {
            return Result.error("手机号不能为空");
        }
        if (!reader.getPhone().matches("^1[3-9]\\d{9}$")) {
            return Result.error("请输入正确的11位手机号");
        }

        reader.setPassword(passwordEncoder.encode(reader.getPassword()));
        reader.setMaxBorrowCount(5);
        reader.setCurrentBorrowCount(0);
        reader.setOverdueStatus(0);
        reader.setRegisterTime(java.time.LocalDateTime.now());

        readerMapper.insert(reader);
        return Result.success("注册成功");
    }
}
