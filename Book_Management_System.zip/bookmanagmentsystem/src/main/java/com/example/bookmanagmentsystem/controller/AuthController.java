package com.example.bookmanagmentsystem.controller;

import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.Reader;
import com.example.bookmanagmentsystem.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/admin/login")
    public Result<Map<String, Object>> adminLogin(@RequestBody Map<String, String> loginData) {
        return authService.adminLogin(loginData.get("username"), loginData.get("password"));
    }

    @PostMapping("/reader/login")
    public Result<Map<String, Object>> readerLogin(@RequestBody Map<String, String> loginData) {
        return authService.readerLogin(loginData.get("username"), loginData.get("password"));
    }

    @PostMapping("/reader/register")
    public Result<String> readerRegister(@RequestBody Reader reader) {
        return authService.readerRegister(reader);
    }
    
    @GetMapping("/hash-password/{password}")
    public Result<Map<String, String>> hashPassword(@PathVariable String password) {
        String hashed = passwordEncoder.encode(password);
        Map<String, String> result = new HashMap<>();
        result.put("original", password);
        result.put("hashed", hashed);
        result.put("length", String.valueOf(hashed.length()));
        return Result.success(result);
    }
    
    @GetMapping("/test-password")
    public Result<Map<String, Object>> testPassword() {
        String originalPassword = "admin123";
        String hashedPassword = passwordEncoder.encode(originalPassword);
        boolean matches = passwordEncoder.matches(originalPassword, hashedPassword);
        
        Map<String, Object> result = new HashMap<>();
        result.put("original", originalPassword);
        result.put("hashed", hashedPassword);
        result.put("length", hashedPassword.length());
        result.put("matches", matches);
        
        return Result.success(result);
    }
}
