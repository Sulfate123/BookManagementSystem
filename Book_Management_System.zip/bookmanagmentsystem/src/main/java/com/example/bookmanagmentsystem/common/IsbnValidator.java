package com.example.bookmanagmentsystem.common;

public class IsbnValidator {

    public static ValidationResult validate(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) {
            return new ValidationResult(false, "ISBN不能为空");
        }

        String cleaned = isbn.replaceAll("[-\\s]", "");

        if (!cleaned.matches("\\d{13}")) {
            return new ValidationResult(false, "ISBN格式错误，应为13位数字（如：9787111234562）");
        }

        if (!cleaned.startsWith("978") && !cleaned.startsWith("979")) {
            return new ValidationResult(false, "ISBN应以978或979开头");
        }

        if (!isValidIsbnChecksum(cleaned)) {
            return new ValidationResult(false, "ISBN校验码错误");
        }

        return new ValidationResult(true, null);
    }

    private static boolean isValidIsbnChecksum(String isbn) {
        int sum = 0;
        for (int i = 0; i < 12; i++) {
            int digit = Character.getNumericValue(isbn.charAt(i));
            sum += (i % 2 == 0) ? digit : digit * 3;
        }

        int checksum = 10 - (sum % 10);
        if (checksum == 10) checksum = 0;

        return checksum == Character.getNumericValue(isbn.charAt(12));
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String errorMessage;

        public ValidationResult(boolean valid, String errorMessage) {
            this.valid = valid;
            this.errorMessage = errorMessage;
        }

        public boolean isValid() {
            return valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}
