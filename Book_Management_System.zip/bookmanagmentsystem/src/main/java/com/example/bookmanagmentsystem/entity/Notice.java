package com.example.bookmanagmentsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("notice")
public class Notice {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String title;

    private String content;

    private LocalDateTime publishTime;

    private Integer isTop;

    private LocalDateTime expireTime;

    private Long adminId;

    private LocalDateTime createTime;

    @TableLogic
    private Integer deleted;
}
