package com.example.bookmanagmentsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.Book;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.mapper.BookMapper;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookMapper bookMapper;
    
    private final BorrowRecordMapper borrowRecordMapper;

    public Result<Page<Book>> getBookList(Integer pageNum, Integer pageSize, String keyword, Long categoryId) {
        Page<Book> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Book> wrapper = new LambdaQueryWrapper<>();

        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(Book::getBookName, keyword)
                    .or()
                    .like(Book::getAuthor, keyword)
                    .or()
                    .like(Book::getIsbn, keyword);
        }

        if (categoryId != null) {
            wrapper.eq(Book::getCategoryId, categoryId);
        }

        wrapper.orderByDesc(Book::getCreateTime);

        Page<Book> bookPage = bookMapper.selectPage(page, wrapper);
        return Result.success(bookPage);
    }

    public Result<Book> getBookById(Long id) {
        Book book = bookMapper.selectById(id);
        if (book == null) {
            return Result.error("图书不存在");
        }
        return Result.success(book);
    }

    public Result<String> addBook(Book book) {
        book.setAvailableStock(book.getTotalStock());
        book.setCreateTime(java.time.LocalDateTime.now());
        bookMapper.insert(book);
        return Result.success("添加成功");
    }

    public Result<String> updateBook(Book book) {
        Book existingBook = bookMapper.selectById(book.getId());
        if (existingBook == null) {
            return Result.error("图书不存在");
        }

        if (book.getTotalStock() != null) {
            int stockDiff = book.getTotalStock() - existingBook.getTotalStock();
            book.setAvailableStock(existingBook.getAvailableStock() + stockDiff);
        }

        bookMapper.updateById(book);
        return Result.success("更新成功");
    }

    public Result<String> deleteBook(Long id) {
        bookMapper.deleteById(id);
        return Result.success("删除成功");
    }

    public Result<List<Book>> getHotBooks() {
        // 统计每本图书的借阅次数（只统计已完成的借阅记录）
        Map<Long, Long> borrowCountMap = borrowRecordMapper.selectList(
            new LambdaQueryWrapper<BorrowRecord>()
                .isNotNull(BorrowRecord::getReturnTime)
        ).stream()
        .collect(Collectors.groupingBy(
            BorrowRecord::getBookId,
            Collectors.counting()
        ));
        
        // 获取所有图书
        List<Book> allBooks = bookMapper.selectList(null);
        
        // 按借阅次数排序，返回前10本
        List<Book> hotBooks = allBooks.stream()
                .sorted((b1, b2) -> {
                    long count1 = borrowCountMap.getOrDefault(b1.getId(), 0L);
                    long count2 = borrowCountMap.getOrDefault(b2.getId(), 0L);
                    return Long.compare(count2, count1); // 降序排列
                })
                .limit(10)
                .collect(Collectors.toList());
        
        return Result.success(hotBooks);
    }

    public Result<List<Book>> getNewBooks() {
        LambdaQueryWrapper<Book> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(Book::getCreateTime);
        wrapper.last("LIMIT 10");
        List<Book> books = bookMapper.selectList(wrapper);
        return Result.success(books);
    }
}
