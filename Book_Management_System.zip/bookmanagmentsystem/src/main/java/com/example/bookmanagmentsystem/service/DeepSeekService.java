package com.example.bookmanagmentsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.dto.AiRequest;
import com.example.bookmanagmentsystem.dto.AiResponse;
import com.example.bookmanagmentsystem.entity.Book;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.entity.ChatHistory;
import com.example.bookmanagmentsystem.mapper.BookMapper;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import com.example.bookmanagmentsystem.mapper.ChatHistoryMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DeepSeekService {
    
    private final WebClient webClient;
    
    private final BookMapper bookMapper;
    
    private final BorrowRecordMapper borrowRecordMapper;
    
    private final ChatHistoryMapper chatHistoryMapper;
    
    private final BorrowService borrowService;
    
    private final ObjectMapper objectMapper;
    
    @Value("${deepseek.api.key}")
    private String apiKey;
    
    @Value("${deepseek.api.url}")
    private String apiUrl;
    
    @Value("${deepseek.model}")
    private String model;
    
    private static final int MAX_HISTORY_MESSAGES = 10;
    
    public Flux<String> processMessageStream(AiRequest request) {
        if (request.getUserId() == null) {
            request.setUserId(0L);
        }
        
        if (request.getRole() == null || request.getRole().isEmpty()) {
            request.setRole("reader");
        }
        
        System.out.println("AI请求 - userId: " + request.getUserId() + ", role: " + request.getRole() + ", message: " + request.getMessage());
        
        String message = request.getMessage();
        
        if (message.length() > 200) {
            try {
                AiResponse response = new AiResponse();
                response.setCode(400);
                response.setReply("文本过长，请重新输入（最多200字）");
                String json = objectMapper.writeValueAsString(response);
                return Flux.just(json);
            } catch (Exception e) {
                return Flux.error(e);
            }
        }
        
        String userRole = request.getRole();
        String lowerMessage = message.toLowerCase();
        
        if (isMyBorrowQuery(lowerMessage)) {
            if (request.getUserId() == null || request.getUserId() == 0) {
                try {
                    AiResponse response = new AiResponse();
                    response.setCode(401);
                    response.setReply("请先登录查看您的借阅记录 📖");
                    String json = objectMapper.writeValueAsString(response);
                    return Flux.just(json);
                } catch (Exception e) {
                    return Flux.error(e);
                }
            }
            System.out.println("✅ 识别为查询个人借阅记录，userId: " + request.getUserId());
            return handleMyBorrowRecordsStream(request.getUserId());
        } else if (isBorrowRequest(lowerMessage)) {
            if (request.getUserId() == null || request.getUserId() == 0) {
                try {
                    AiResponse response = new AiResponse();
                    response.setCode(401);
                    response.setReply("请先登录后再借阅图书哦 📚");
                    String json = objectMapper.writeValueAsString(response);
                    return Flux.just(json);
                } catch (Exception e) {
                    return Flux.error(e);
                }
            }
            System.out.println("✅ 识别为借阅图书请求");
            return handleBorrowBookStream(lowerMessage, request.getUserId());
        } else if (isNewBooksQuery(lowerMessage)) {
            System.out.println("✅ 识别为新书推荐");
            return handleNewBooksRecommendationStream();
        } else if (isHotBooksQuery(lowerMessage)) {
            System.out.println("✅ 识别为热门图书推荐");
            return handleHotBooksRecommendationStream();
        } else if ("admin".equals(userRole) && isAdminBookManage(lowerMessage)) {
            System.out.println("✅ 识别为管理员图书管理");
            return handleAdminBookManageStream(lowerMessage);
        } else if ("admin".equals(userRole) && isAdminReaderManage(lowerMessage)) {
            System.out.println("✅ 识别为管理员读者管理");
            return handleAdminReaderManageStream(lowerMessage);
        } else if ("admin".equals(userRole) && isAdminNoticeManage(lowerMessage)) {
            System.out.println("✅ 识别为管理员公告管理");
            return handleAdminNoticeManageStream(lowerMessage);
        } else if ("admin".equals(userRole) && isAdminBorrowManage(lowerMessage)) {
            System.out.println("✅ 识别为管理员借阅管理");
            return handleAdminBorrowManageStream(lowerMessage);
        } else if (isBookQuery(lowerMessage)) {
            System.out.println("✅ 识别为查询图书");
            return handleBookQueryStream(lowerMessage);
        } else if (isReturnQuery(lowerMessage)) {
            System.out.println("✅ 识别为还书相关问题");
            return handleReturnQueryStream();
        } else if ("admin".equals(userRole) && (lowerMessage.contains("统计") || lowerMessage.contains("数据"))) {
            System.out.println("✅ 识别为管理员统计请求");
            return handleAdminStatisticsStream();
        } else if ("admin".equals(userRole) && (lowerMessage.contains("所有图书") || lowerMessage.contains("图书列表"))) {
            System.out.println("✅ 识别为查看所有图书");
            return handleAllBooksStream();
        } else {
            System.out.println("❌ 未识别具体意图，使用通用对话");
            return callDeepSeekAPIStream(request);
        }
    }
    
    private boolean isBookQuery(String message) {
        String[] questionKeywords = {"怎么", "如何", "怎样", "可以吗", "能不能", "为什么", "什么是", "哪里"};
        for (String keyword : questionKeywords) {
            if (message.contains(keyword)) {
                return false;
            }
        }
        
        String[] queryKeywords = {"查询", "搜索", "找", "我想看", "看看", "有没有", "查找", "帮我找"};
        
        String[] bookKeywords = {"书", "图书", "书籍", "信息", "详情", "介绍"};
        
        boolean hasQueryKeyword = false;
        for (String keyword : queryKeywords) {
            if (message.contains(keyword)) {
                hasQueryKeyword = true;
                break;
            }
        }
        
        if (hasQueryKeyword) {
            return true;
        }
        
        boolean hasBookKeyword = false;
        for (String keyword : bookKeywords) {
            if (message.contains(keyword)) {
                hasBookKeyword = true;
                break;
            }
        }
        
        if (hasBookKeyword) {
            return true;
        }
        
        if (message.length() >= 2 && message.length() <= 20) {
            String[] excludeKeywords = {"你好", "谢谢", "再见", "帮助", "帮助我"};
            for (String exclude : excludeKeywords) {
                if (message.contains(exclude)) {
                    return false;
                }
            }
            return true;
        }
        
        return false;
    }
    
    private boolean isBorrowRequest(String message) {
        if (isMyBorrowQuery(message)) {
            return false;
        }
        
        String[] questionKeywords = {"怎么", "如何", "怎样", "可以吗", "能不能", "怎么借", "如何借"};
        for (String keyword : questionKeywords) {
            if (message.contains(keyword)) {
                return false;
            }
        }
        
        String[] borrowKeywords = {"我要借", "想借", "帮我借", "借阅图书", "借书", "借阅"};
        
        for (String keyword : borrowKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isMyBorrowQuery(String message) {
        String[] myBorrowKeywords = {"我的借阅", "借阅记录", "我借的书", "我借了", "借过的书", "我的借书", "查看借阅", "借阅历史", "我借的", "借了什么", "查询借阅"};
        
        for (String keyword : myBorrowKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isHotBooksQuery(String message) {
        String[] hotKeywords = {"热门", "最热", "排行榜", "popular", "hot"};
        
        for (String keyword : hotKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isNewBooksQuery(String message) {
        String[] newKeywords = {"新书", "最新", "最近", "新到", "new", "latest"};
        String[] bookKeywords = {"书", "图书"};
        
        boolean hasNewKeyword = false;
        for (String keyword : newKeywords) {
            if (message.contains(keyword)) {
                hasNewKeyword = true;
                break;
            }
        }
        
        if (!hasNewKeyword) {
            return false;
        }
        
        boolean hasBookKeyword = false;
        for (String keyword : bookKeywords) {
            if (message.contains(keyword)) {
                hasBookKeyword = true;
                break;
            }
        }
        
        return hasBookKeyword;
    }

    private boolean isReturnQuery(String message) {
        String[] returnKeywords = {
            "还书", "归还", "退回", "返还", "怎么还", "如何还", "怎样还",
            "还书流程", "还书方式", "归还流程", "怎么归还", "如何归还",
            "在哪还", "哪里还", "去还", "要去还", "到图书馆"
        };
        
        for (String keyword : returnKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private boolean isAdminBookManage(String message) {
        String[] keywords = {"添加图书", "新增图书", "删除图书", "编辑图书", "修改图书", "上架", "下架"};
        for (String keyword : keywords) {
            if (message.contains(keyword)) return true;
        }
        return false;
    }

    private boolean isAdminReaderManage(String message) {
        String[] keywords = {"读者管理", "添加读者", "删除读者", "编辑读者", "查看读者", "读者列表"};
        for (String keyword : keywords) {
            if (message.contains(keyword)) return true;
        }
        return false;
    }

    private boolean isAdminNoticeManage(String message) {
        String[] keywords = {"发布公告", "添加公告", "删除公告", "编辑公告", "公告管理", "查看公告"};
        for (String keyword : keywords) {
            if (message.contains(keyword)) return true;
        }
        return false;
    }

    private boolean isAdminBorrowManage(String message) {
        String[] keywords = {"借阅管理", "借阅记录", "归还图书", "逾期", "借阅列表", "所有借阅"};
        for (String keyword : keywords) {
            if (message.contains(keyword)) return true;
        }
        return false;
    }

    private Flux<String> handleReturnQueryStream() {
        try {
            String reply = "📍 还书说明：\n\n"
                + "1️⃣ 请到图书馆前台办理线下归还手续\n"
                + "2️⃣ 请携带您的读者证和要归还的图书\n"
                + "3️⃣ 请在借阅期限内归还，逾期会产生罚款哦\n\n"
                + "⏰ 借阅期限为30天，每个读者最多可同时借阅5本图书\n"
                + "💡 您可以在AI助手中查看借阅记录和应还时间\n"
                + "❌ 还书需在图书馆现场办理，暂不支持线上归还";
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply);
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送还书说明: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private Flux<String> handleAdminBookManageStream(String message) {
        try {
            String reply = "📚 正在为您打开图书管理...";
            String action = "open_book_modal";
            
            if (message.contains("添加") || message.contains("新增")) {
                action = "add_book";
                reply = "📚 正在为您打开添加图书表单...";
            } else if (message.contains("删除")) {
                action = "switch_books";
                reply = "📚 正在跳转到图书管理页面，请在列表中点击「删除」按钮...";
            } else if (message.contains("编辑") || message.contains("修改")) {
                action = "switch_books";
                reply = "📚 正在跳转到图书管理页面，请在列表中点击「编辑」按钮...";
            } else {
                action = "switch_books";
                reply = "📚 正在跳转到图书管理页面...";
            }
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply);
            response.setAction(action);
            String json = objectMapper.writeValueAsString(response);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private Flux<String> handleAdminReaderManageStream(String message) {
        try {
            String reply = "👥 正在为您跳转到读者管理...";
            String action = "switch_readers";
            
            if (message.contains("编辑") || message.contains("修改")) {
                reply = "👥 正在跳转到读者管理页面，请在列表中点击「编辑」按钮...";
            } else if (message.contains("删除")) {
                reply = "👥 正在跳转到读者管理页面，请在列表中点击「删除」按钮...";
            }
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply);
            response.setAction(action);
            String json = objectMapper.writeValueAsString(response);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private Flux<String> handleAdminNoticeManageStream(String message) {
        try {
            String reply = "📢 正在为您跳转到公告管理...";
            String action = "switch_notices";
            
            if (message.contains("发布") || message.contains("添加")) {
                action = "add_notice";
                reply = "📢 正在为您打开发布公告表单...";
            } else if (message.contains("编辑") || message.contains("修改")) {
                reply = "📢 正在跳转到公告管理页面，请在列表中点击「编辑」按钮...";
            } else if (message.contains("删除")) {
                reply = "📢 正在跳转到公告管理页面，请在列表中点击「删除」按钮...";
            }
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply);
            response.setAction(action);
            String json = objectMapper.writeValueAsString(response);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private Flux<String> handleAdminBorrowManageStream(String message) {
        try {
            String reply = "📖 正在为您跳转到借阅管理...";
            String action = "switch_borrows";
            
            if (message.contains("归还") || message.contains("还书")) {
                reply = "📖 正在跳转到借阅管理页面，请在列表中点击「归还」按钮...";
            }
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply);
            response.setAction(action);
            String json = objectMapper.writeValueAsString(response);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private void saveUserMessage(AiRequest request) {
        // 不再保存到数据库，仅保留方法以避免编译错误
        System.out.println("用户消息已跳过保存: " + request.getMessage());
    }
    
    private void saveAssistantMessage(AiRequest request, AiResponse response) {
        // 不再保存到数据库，仅保留方法以避免编译错误
        System.out.println("AI回复已跳过保存: " + response.getReply());
    }
    
    private List<ChatHistory> getRecentHistory(Long userId) {
        LambdaQueryWrapper<ChatHistory> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ChatHistory::getUserId, userId);
        wrapper.orderByDesc(ChatHistory::getCreateTime);
        wrapper.last("LIMIT " + MAX_HISTORY_MESSAGES);
        
        List<ChatHistory> histories = chatHistoryMapper.selectList(wrapper);
        
        histories.sort((a, b) -> a.getCreateTime().compareTo(b.getCreateTime()));
        
        return histories;
    }
    
    private Flux<String> handleBookQueryStream(String message) {
        String keyword = extractKeyword(message);
        List<Book> books = bookMapper.selectList(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Book>()
                .like(Book::getBookName, keyword)
                .or()
                .like(Book::getAuthor, keyword)
                .last("LIMIT 5")
        );
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_books");
            
            if (books.isEmpty()) {
                response.setReply("抱歉，没有找到相关图书。您可以尝试其他关键词搜索。");
                response.setData(new ArrayList<>());
            } else {
                response.setReply("为您找到以下图书：");
                response.setData(books);
            }
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送图书查询结果: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
    
    private Flux<String> handleHotBooksRecommendationStream() {
        Map<Long, Long> borrowCountMap = borrowRecordMapper.selectList(
            new LambdaQueryWrapper<BorrowRecord>()
                .isNotNull(BorrowRecord::getReturnTime)
        ).stream()
        .collect(Collectors.groupingBy(
            BorrowRecord::getBookId,
            Collectors.counting()
        ));
        
        List<Book> allBooks = bookMapper.selectList(null);
        
        List<Book> hotBooks = allBooks.stream()
                .sorted((b1, b2) -> {
                    long count1 = borrowCountMap.getOrDefault(b1.getId(), 0L);
                    long count2 = borrowCountMap.getOrDefault(b2.getId(), 0L);
                    return Long.compare(count2, count1);
                })
                .limit(5)
                .collect(Collectors.toList());
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_books");
            
            if (hotBooks.isEmpty()) {
                response.setReply("暂无热门图书推荐，快去借阅图书吧！📚");
                response.setData(new ArrayList<>());
            } else {
                response.setReply("🔥 为您推荐热门图书TOP5（按借阅次数排序）：");
                response.setData(hotBooks);
            }
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送热门推荐结果: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
    
    private Flux<String> handleNewBooksRecommendationStream() {
        List<Book> newBooks = bookMapper.selectList(
            new LambdaQueryWrapper<Book>()
                .orderByDesc(Book::getPublishDate)
                .last("LIMIT 5")
        );
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_books");
            
            if (newBooks.isEmpty()) {
                response.setReply("暂无新书推荐。");
                response.setData(new ArrayList<>());
            } else {
                response.setReply("🆕 为您推荐最新出版的图书TOP5：");
                response.setData(newBooks);
            }
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送新书推荐结果: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
    
    private Flux<String> handleBorrowBookStream(String message, Long userId) {
        Long bookId = extractBookId(message);
        
        if (bookId == null) {
            try {
                AiResponse response = new AiResponse();
                response.setCode(400);
                response.setReply("请提供要借阅的图书ID，例如：我想借阅图书1");
                String json = objectMapper.writeValueAsString(response);
                System.out.println("发送错误响应: " + json);
                return Flux.just(json);
            } catch (Exception e) {
                return Flux.error(e);
            }
        }
        
        try {
            Result<String> result = borrowService.borrowBook(userId, bookId);
            
            AiResponse response = new AiResponse();
            response.setCode(result.getCode());
            response.setReply(result.getMessage());
            response.setAction("borrow_book");
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送借阅结果: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            try {
                AiResponse response = new AiResponse();
                response.setCode(500);
                response.setReply("借阅失败：" + e.getMessage());
                String json = objectMapper.writeValueAsString(response);
                return Flux.just(json);
            } catch (Exception ex) {
                return Flux.error(ex);
            }
        }
    }
    
    private Flux<String> handleMyBorrowRecordsStream(Long userId) {
        List<BorrowRecord> records = borrowRecordMapper.selectList(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<BorrowRecord>()
                .eq(BorrowRecord::getReaderId, userId)
                .orderByDesc(BorrowRecord::getBorrowTime)
                .last("LIMIT 10")
        );
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_borrow_records");
            response.setReply("您的借阅记录：");
            response.setData(records);
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送借阅记录: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
    
    private Flux<String> handleAdminStatisticsStream() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalBooks", bookMapper.selectCount(null));
        stats.put("totalBorrows", borrowRecordMapper.selectCount(null));
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_statistics");
            response.setReply("当前系统统计数据：");
            response.setData(stats);
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送统计数据: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
    
    private Flux<String> handleAllBooksStream() {
        List<Book> books = bookMapper.selectList(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Book>()
                .orderByDesc(Book::getCreateTime)
                .last("LIMIT 20")
        );
        
        try {
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setAction("show_all_books");
            response.setReply("系统图书列表：");
            response.setData(books);
            
            String json = objectMapper.writeValueAsString(response);
            System.out.println("发送图书列表: " + json);
            return Flux.just(json);
        } catch (Exception e) {
            return Flux.error(e);
        }
    }

    private Flux<String> callDeepSeekAPIStream(AiRequest request) {
        String systemPrompt = buildSystemPrompt(request.getRole());
        
        List<ChatHistory> recentHistory = getRecentHistory(request.getUserId());
        
        List<Map<String, String>> messages = new ArrayList<>();
        
        messages.add(Map.of("role", "system", "content", systemPrompt));
        
        for (ChatHistory history : recentHistory) {
            messages.add(Map.of(
                "role", history.getRole(),
                "content", history.getMessage()
            ));
        }
        
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("messages", messages);
        requestBody.put("temperature", 0.7);
        requestBody.put("max_tokens", 1000);
        requestBody.put("stream", true);
        
        System.out.println("\n========== DeepSeek API请求 ==========");
        System.out.println("API URL: " + apiUrl);
        System.out.println("Model: " + model);
        System.out.println("用户消息: " + request.getMessage());
        System.out.println("历史记录数: " + recentHistory.size());
        System.out.println("======================================\n");
        
        StringBuilder fullResponse = new StringBuilder();
        
        return webClient.post()
                .uri(apiUrl)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + apiKey)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToFlux(String.class)
                .doOnNext(chunk -> System.out.println("收到DeepSeek原始数据: " + chunk))
                .flatMap(chunk -> {
                    try {
                        String parsed = parseStreamChunk(chunk);
                        if (parsed != null && !parsed.isEmpty()) {
                            fullResponse.append(parsed);
                            System.out.println("解析出的内容: " + parsed);
                            
                            AiResponse streamResp = new AiResponse();
                            streamResp.setCode(200);
                            streamResp.setReply(parsed);
                            streamResp.setStreaming(true);
                            String json = objectMapper.writeValueAsString(streamResp);
                            return Flux.just(json);
                        }
                        return Flux.<String>empty();
                    } catch (Exception e) {
                        System.err.println("解析chunk失败: " + e.getMessage());
                        return Flux.<String>empty();
                    }
                })
                .concatWith(Flux.defer(() -> {
                    try {
                        String reply = fullResponse.toString().trim();
                        System.out.println("\n========== 最终完整回复 ==========");
                        System.out.println(reply);
                        System.out.println("==================================\n");
                        
                        if (reply.isEmpty()) {
                            reply = "抱歉，AI服务没有返回具体内容，请稍后重试。";
                        }
                        
                        AiResponse finalResp = new AiResponse();
                        finalResp.setCode(200);
                        finalResp.setReply(reply);
                        finalResp.setStreaming(false);
                        String json = objectMapper.writeValueAsString(finalResp);
                        System.out.println("发送最终完成信号: " + json);
                        return Flux.just(json);
                    } catch (Exception e) {
                        System.err.println("序列化最终响应失败: " + e.getMessage());
                        return Flux.empty();
                    }
                }))
                .onErrorResume(error -> {
                    try {
                        System.err.println("\n========== DeepSeek API调用错误 ==========");
                        System.err.println("错误信息: " + error.getMessage());
                        error.printStackTrace();
                        System.err.println("===========================================\n");
                        
                        AiResponse fallback = new AiResponse();
                        fallback.setCode(200);
                        fallback.setReply("抱歉，AI服务暂时不可用。您可以直接问我关于图书的问题，例如：查询Java相关图书、我想借阅图书1、怎么借书等。");
                        fallback.setStreaming(false);
                        String json = objectMapper.writeValueAsString(fallback);
                        return Flux.just(json);
                    } catch (Exception e) {
                        System.err.println("创建降级响应失败: " + e.getMessage());
                        return Flux.error(e);
                    }
                });
    }
    
    private String parseStreamChunk(String chunk) {
        try {
            System.out.println("========== 开始解析chunk ==========");
            System.out.println("原始chunk: " + chunk);
            
            String data = chunk;
            
            if (chunk.startsWith("data: ")) {
                data = chunk.substring(6);
                System.out.println("检测到SSE格式，提取data: " + data);
            } else {
                System.out.println("非SSE格式，直接使用");
            }
            
            if ("[DONE]".equals(data)) {
                System.out.println("收到[DONE]标记，结束");
                return null;
            }
            
            if (data.trim().isEmpty()) {
                System.out.println("空数据，跳过");
                return null;
            }
            
            JsonNode node = objectMapper.readTree(data);
            System.out.println("解析JSON节点: " + node.toPrettyString());
            
            JsonNode choices = node.path("choices");
            if (choices.isArray() && choices.size() > 0) {
                JsonNode firstChoice = choices.get(0);
                JsonNode delta = firstChoice.path("delta");
                String content = delta.path("content").asText();
                
                System.out.println("提取的内容: '" + content + "'");
                System.out.println("========== chunk解析结束 ==========\n");
                
                return content.isEmpty() ? null : content;
            }
            
            System.out.println("没有找到choices数组");
            System.out.println("========== chunk解析结束 ==========\n");
            return null;
        } catch (Exception e) {
            System.err.println("解析chunk时出错: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    private void saveAssistantMessageFromStream(AiRequest request) {
        // 不再保存到数据库
        System.out.println("AI回复已跳过保存");
    }
    
    private String buildSystemPrompt(String userRole) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("你是书香图书管理系统的智能助手，名字叫'小书童'。你的职责是帮助用户使用图书管理系统。\n\n");
        
        if ("reader".equals(userRole)) {
            prompt.append("当前用户是读者，你可以：\n");
            prompt.append("1. 帮助查询图书信息\n");
            prompt.append("2. 帮助借阅图书（需要提供图书ID）\n");
            prompt.append("3. 查看用户的借阅记录\n");
            prompt.append("4. 回答图书相关的问题\n");
            prompt.append("5. 推荐热门图书和新书\n\n");
            prompt.append("你不能执行管理员操作，如删除图书、管理用户等。\n\n");
        } else if ("admin".equals(userRole)) {
            prompt.append("当前用户是管理员，你可以：\n");
            prompt.append("1. 执行所有读者功能\n");
            prompt.append("2. 查看系统统计数据\n");
            prompt.append("3. 查看所有图书列表\n");
            prompt.append("4. 协助管理图书、用户、借阅记录等\n");
            prompt.append("5. 推荐热门图书和新书\n\n");
        }
        
        prompt.append("请用简洁友好的中文回复，适当使用emoji让对话更生动。\n\n");
        prompt.append("重要提示：\n");
        prompt.append("- 当展示图书列表时，不要提及馆藏位置、书架号等物理位置信息\n");
        prompt.append("- 不要提及出版年份，除非用户明确询问\n");
        prompt.append("- 图书的作者、出版社、库存等信息会从数据库自动获取并展示，你不需要在文字回复中重复这些信息\n");
        prompt.append("- 只需要用简短的友好语句介绍即可，例如：'为您找到以下图书：'\n\n");
        prompt.append("常见问题回答指南：\n");
        prompt.append("- 如果用户问'怎么借阅图书'、'如何借书'、'怎样借书'等问题，请详细说明步骤：\n");
        prompt.append("  1️⃣ 首先登录您的账号\n");
        prompt.append("  2️⃣ 在首页或图书页面搜索想要的图书\n");
        prompt.append("  3️⃣ 点击图书卡片查看详情\n");
        prompt.append("  4️⃣ 点击'立即借阅'按钮即可完成借阅\n");
        prompt.append("  💡 您也可以直接在对话框输入'我要借阅图书X'（X是图书ID）来快速借阅\n\n");
        prompt.append("- ⚠️ 重要区分：'还书'和'借书'是完全不同的操作！\n");
        prompt.append("- 如果用户问'怎么还书'、'如何归还'、'怎样还书'、'还书流程'等问题，请说明：\n");
        prompt.append("  📍 还书需要到图书馆前台办理线下归还手续\n");
        prompt.append("  📋 请携带您的读者证和要归还的图书\n");
        prompt.append("  ⏰ 请在借阅期限内归还，逾期会产生罚款哦\n");
        prompt.append("  💡 您可以在AI助手中查看借阅记录和应还时间\n");
        prompt.append("  ❌ 注意：还书不能在系统中在线完成，必须到图书馆现场办理\n\n");
        prompt.append("- 如果用户问'怎么注册'、'如何注册'，请说明：\n");
        prompt.append("  点击右上角的'注册'按钮，填写用户名、密码、姓名等信息即可完成注册\n\n");
        prompt.append("- 如果用户问'忘记密码怎么办'，请说明：\n");
        prompt.append("  请联系管理员重置密码，或者使用找回密码功能（如果已配置）\n\n");
        prompt.append("- 如果用户问'可以借几本书'、'借阅限制'，请说明：\n");
        prompt.append("  每个读者最多可以借阅5本图书，借阅期限为30天\n\n");
        prompt.append("重要：这是一个多轮对话场景，请根据对话历史理解用户的意图，保持对话的连贯性。");
        
        return prompt.toString();
    }

    private AiResponse parseDeepSeekResponse(String responseBody) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            String reply = root.path("choices").get(0).path("message").path("content").asText();
            
            AiResponse response = new AiResponse();
            response.setCode(200);
            response.setReply(reply.trim());
            return response;
        } catch (Exception e) {
            AiResponse response = new AiResponse();
            response.setCode(500);
            response.setReply("解析AI响应失败");
            return response;
        }
    }
    
    private String extractKeyword(String message) {
        String[] removeWords = {
            "查询", "搜索", "找", "我想看", "看看", "有没有", "查找", "帮我找",
            "查看", "搜", "想看", "想找", "查一下", "帮我查", "帮我搜",
            "我", "想", "要", "请", "帮助", "帮忙", "一下", "一个", "本", "部"
        };
        
        String keyword = message;
        for (String word : removeWords) {
            keyword = keyword.replace(word, "");
        }
        
        keyword = keyword.trim();
        
        return keyword.isEmpty() ? message.trim() : keyword;
    }
    
    private Long extractBookId(String message) {
        try {
            String idStr = message.replaceAll("[^0-9]", "");
            return idStr.isEmpty() ? null : Long.parseLong(idStr);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
