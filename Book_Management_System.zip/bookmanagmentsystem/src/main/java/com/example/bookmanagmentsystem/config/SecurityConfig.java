package com.example.bookmanagmentsystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**", "/api/books/**", "/api/borrow/**", "/api/ai/**", "/api/readers/**", "/api/notices/**", "/api/statistics/**", "/api/categories/**", "/api/upload/**", "/css/**", "/js/**", "/images/**", "/uploads/**", "/", "/index.html", "/login.html", "/register.html", "/dashboard.html", "/books.html", "/admin.html", "/book-detail.html").permitAll()
                .anyRequest().authenticated()
            );

        return http.build();
    }
}
