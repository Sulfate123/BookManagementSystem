package com.example.bookmanagmentsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.entity.Reader;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import com.example.bookmanagmentsystem.mapper.ReaderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/readers")
@RequiredArgsConstructor
public class ReaderController {

    private final ReaderMapper readerMapper;
    
    private final BorrowRecordMapper borrowRecordMapper;

    @GetMapping("/{id}")
    public Result<Map<String, Object>> getReaderById(@PathVariable Long id) {
        Reader reader = readerMapper.selectById(id);
        if (reader == null) {
            return Result.error("读者不存在");
        }

        Map<String, Object> readerData = new HashMap<>();
        readerData.put("id", reader.getId());
        readerData.put("username", reader.getUsername());
        readerData.put("realName", reader.getRealName());
        readerData.put("avatar", reader.getAvatar());
        readerData.put("phone", reader.getPhone());
        readerData.put("studentNumber", reader.getStudentNumber());
        readerData.put("maxBorrowCount", reader.getMaxBorrowCount());
        readerData.put("currentBorrowCount", reader.getCurrentBorrowCount());

        if (reader.getRegisterTime() != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            readerData.put("registerTime", reader.getRegisterTime().format(formatter));
        }

        return Result.success(readerData);
    }
    
    @GetMapping("/all")
    public Result<List<Reader>> getAllReaders() {
        List<Reader> readers = readerMapper.selectAllReaders();
        
        readers.forEach(reader -> reader.setPassword(null));
        
        return Result.success(readers);
    }

    @PutMapping
    public Result<String> updateReader(@RequestBody Reader reader) {
        Reader existingReader = readerMapper.selectById(reader.getId());
        if (existingReader == null) {
            return Result.error("读者不存在");
        }

        existingReader.setRealName(reader.getRealName());
        existingReader.setPhone(reader.getPhone());
        existingReader.setStudentNumber(reader.getStudentNumber());
        if (reader.getAvatar() != null) {
            existingReader.setAvatar(reader.getAvatar());
        }

        readerMapper.updateById(existingReader);

        return Result.success("更新成功");
    }
    
    @DeleteMapping("/{id}")
    public Result<String> deleteReader(@PathVariable Long id) {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getReaderId, id)
                .and(w -> w.isNull(BorrowRecord::getReturnTime)
                        .or()
                        .eq(BorrowRecord::getStatus, 0)
                        .or()
                        .eq(BorrowRecord::getStatus, 2));
        
        long count = borrowRecordMapper.selectCount(wrapper);
        if (count > 0) {
            return Result.error("该读者存在未归还图书，无法删除");
        }
        
        readerMapper.physicalDeleteById(id);
        return Result.success("删除成功");
    }
}
