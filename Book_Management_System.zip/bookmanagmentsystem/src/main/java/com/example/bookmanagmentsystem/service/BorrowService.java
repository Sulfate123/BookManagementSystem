package com.example.bookmanagmentsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.dto.BorrowRecordVO;
import com.example.bookmanagmentsystem.entity.Book;
import com.example.bookmanagmentsystem.entity.BorrowRecord;
import com.example.bookmanagmentsystem.entity.Reader;
import com.example.bookmanagmentsystem.mapper.BookMapper;
import com.example.bookmanagmentsystem.mapper.BorrowRecordMapper;
import com.example.bookmanagmentsystem.mapper.ReaderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class BorrowService {
    
    private final BorrowRecordMapper borrowRecordMapper;
    
    private final BookMapper bookMapper;
    
    private final ReaderMapper readerMapper;
    
    private static final int DEFAULT_BORROW_DAYS = 30;
    
    private static final int MAX_RENEW_COUNT = 1;
    
    private static final BigDecimal OVERDUE_FINE_PER_DAY = new BigDecimal("0.5");
    
    @Transactional
    public Result<String> borrowBook(Long readerId, Long bookId) {
        Reader reader = readerMapper.selectById(readerId);
        if (reader == null) {
            return Result.error("读者不存在");
        }
        
        if (reader.getOverdueStatus() == 1) {
            return Result.error("您有逾期未还图书，无法借书");
        }
        
        if (reader.getCurrentBorrowCount() >= reader.getMaxBorrowCount()) {
            return Result.error("已达到最大借阅数量");
        }
        
        Book book = bookMapper.selectById(bookId);
        if (book == null) {
            return Result.error("图书不存在");
        }
        
        if (book.getAvailableStock() <= 0) {
            return Result.error("图书库存不足");
        }
        
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getReaderId, readerId)
                .eq(BorrowRecord::getBookId, bookId)
                .eq(BorrowRecord::getStatus, 0);
        if (borrowRecordMapper.selectCount(wrapper) > 0) {
            return Result.error("您已借阅此图书");
        }
        
        BorrowRecord record = new BorrowRecord();
        record.setReaderId(readerId);
        record.setBookId(bookId);
        record.setBorrowTime(LocalDateTime.now());
        record.setDueTime(LocalDateTime.now().plusDays(DEFAULT_BORROW_DAYS));
        record.setExpectedReturnTime(LocalDateTime.now().plusDays(DEFAULT_BORROW_DAYS));
        record.setRenewCount(0);
        record.setOverdueDays(0);
        record.setFineAmount(BigDecimal.ZERO);
        record.setStatus(0);
        
        borrowRecordMapper.insert(record);
        
        book.setAvailableStock(book.getAvailableStock() - 1);
        bookMapper.updateById(book);
        
        reader.setCurrentBorrowCount(reader.getCurrentBorrowCount() + 1);
        readerMapper.updateById(reader);
        
        return Result.success("借阅成功");
    }
    
    @Transactional
    public Result<String> borrowBookWithExpectedTime(Map<String, Object> params) {
        Long readerId = Long.valueOf(params.get("readerId").toString());
        Long bookId = Long.valueOf(params.get("bookId").toString());
        String expectedReturnTimeStr = params.get("expectedReturnTime").toString();
        
        Reader reader = readerMapper.selectById(readerId);
        if (reader == null) {
            return Result.error("读者不存在");
        }
        
        if (reader.getOverdueStatus() == 1) {
            return Result.error("您有逾期未还图书，无法借书");
        }
        
        if (reader.getCurrentBorrowCount() >= reader.getMaxBorrowCount()) {
            return Result.error("已达到最大借阅数量");
        }
        
        Book book = bookMapper.selectById(bookId);
        if (book == null) {
            return Result.error("图书不存在");
        }
        
        if (book.getAvailableStock() <= 0) {
            return Result.error("图书库存不足");
        }
        
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getReaderId, readerId)
                .eq(BorrowRecord::getBookId, bookId)
                .eq(BorrowRecord::getStatus, 0);
        if (borrowRecordMapper.selectCount(wrapper) > 0) {
            return Result.error("您已借阅此图书");
        }
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime expectedReturnTime = LocalDateTime.parse(expectedReturnTimeStr + "T00:00:00");
        
        BorrowRecord record = new BorrowRecord();
        record.setReaderId(readerId);
        record.setBookId(bookId);
        record.setBorrowTime(LocalDateTime.now());
        record.setDueTime(expectedReturnTime);
        record.setExpectedReturnTime(expectedReturnTime);
        record.setRenewCount(0);
        record.setOverdueDays(0);
        record.setFineAmount(BigDecimal.ZERO);
        record.setStatus(0);
        
        borrowRecordMapper.insert(record);
        
        book.setAvailableStock(book.getAvailableStock() - 1);
        bookMapper.updateById(book);
        
        reader.setCurrentBorrowCount(reader.getCurrentBorrowCount() + 1);
        readerMapper.updateById(reader);
        
        return Result.success("借阅成功");
    }
    
    @Transactional
    public Result<String> returnBook(Long recordId) {
        BorrowRecord record = borrowRecordMapper.selectById(recordId);
        if (record == null) {
            return Result.error("借阅记录不存在");
        }
        
        if (record.getStatus() == 1) {
            return Result.error("该图书已归还");
        }
        
        LocalDateTime now = LocalDateTime.now();
        record.setReturnTime(now);
        record.setStatus(1);
        
        if (now.isAfter(record.getDueTime())) {
            long overdueDays = java.time.Duration.between(record.getDueTime(), now).toDays();
            record.setOverdueDays((int) overdueDays);
            record.setFineAmount(OVERDUE_FINE_PER_DAY.multiply(new BigDecimal(overdueDays)));
        }
        
        borrowRecordMapper.updateById(record);
        
        Book book = bookMapper.selectById(record.getBookId());
        if (book != null) {
            book.setAvailableStock(book.getAvailableStock() + 1);
            bookMapper.updateById(book);
        }
        
        Reader reader = readerMapper.selectById(record.getReaderId());
        if (reader != null) {
            reader.setCurrentBorrowCount(reader.getCurrentBorrowCount() - 1);
            if (reader.getCurrentBorrowCount() == 0) {
                reader.setOverdueStatus(0);
            }
            readerMapper.updateById(reader);
        }
        
        return Result.success("归还成功");
    }
    
    @Transactional
    public Result<String> renewBook(Long recordId) {
        BorrowRecord record = borrowRecordMapper.selectById(recordId);
        if (record == null) {
            return Result.error("借阅记录不存在");
        }
        
        if (record.getStatus() == 1) {
            return Result.error("该图书已归还");
        }
        
        if (record.getRenewCount() >= MAX_RENEW_COUNT) {
            return Result.error("已达到最大续借次数");
        }
        
        LocalDateTime now = LocalDateTime.now();
        if (now.isAfter(record.getDueTime())) {
            return Result.error("图书已逾期，无法续借");
        }
        
        record.setDueTime(record.getDueTime().plusDays(DEFAULT_BORROW_DAYS));
        record.setRenewCount(record.getRenewCount() + 1);
        
        borrowRecordMapper.updateById(record);
        
        return Result.success("续借成功");
    }
    
    public Result<List<BorrowRecordVO>> getBorrowRecordsByReaderId(Long readerId) {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getReaderId, readerId);
        wrapper.orderByDesc(BorrowRecord::getBorrowTime);
        List<BorrowRecord> records = borrowRecordMapper.selectList(wrapper);
        
        List<BorrowRecordVO> result = new ArrayList<>();
        for (BorrowRecord record : records) {
            BorrowRecordVO vo = new BorrowRecordVO(record);
            
            Book book = bookMapper.selectById(record.getBookId());
            if (book != null) {
                vo.setBookName(book.getBookName());
            }
            
            result.add(vo);
        }
        
        return Result.success(result);
    }
    
    public Result<List<BorrowRecord>> getAllBorrowRecords() {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(BorrowRecord::getBorrowTime);
        List<BorrowRecord> records = borrowRecordMapper.selectList(wrapper);
        return Result.success(records);
    }
    
    public Result<List<BorrowRecordVO>> getAllBorrowRecordsWithDetails() {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(BorrowRecord::getBorrowTime);
        List<BorrowRecord> records = borrowRecordMapper.selectList(wrapper);
        
        List<BorrowRecordVO> result = new ArrayList<>();
        for (BorrowRecord record : records) {
            BorrowRecordVO vo = new BorrowRecordVO(record);
            
            Reader reader = readerMapper.selectById(record.getReaderId());
            if (reader != null) {
                vo.setReaderName(reader.getUsername());
            }
            
            Book book = bookMapper.selectById(record.getBookId());
            if (book != null) {
                vo.setBookName(book.getBookName());
            }
            
            result.add(vo);
        }
        
        return Result.success(result);
    }
    
    public Result<List<BorrowRecord>> getOverdueRecords() {
        LambdaQueryWrapper<BorrowRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(BorrowRecord::getStatus, 0)
                .lt(BorrowRecord::getDueTime, LocalDateTime.now());
        List<BorrowRecord> records = borrowRecordMapper.selectList(wrapper);
        return Result.success(records);
    }
}
