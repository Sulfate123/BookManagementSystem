package com.example.bookmanagmentsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.example.bookmanagmentsystem.common.Result;
import com.example.bookmanagmentsystem.entity.Notice;
import com.example.bookmanagmentsystem.mapper.NoticeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/notices")
@RequiredArgsConstructor
public class NoticeController {

    private final NoticeMapper noticeMapper;

    @GetMapping
    public Result<List<Notice>> getAllNotices() {
        List<Notice> notices = noticeMapper.selectList(
                new LambdaQueryWrapper<Notice>()
                        .orderByDesc(Notice::getIsTop)
                        .orderByDesc(Notice::getPublishTime)
        );
        return Result.success(notices);
    }

    @GetMapping("/{id}")
    public Result<Notice> getNoticeById(@PathVariable Long id) {
        Notice notice = noticeMapper.selectById(id);
        if (notice == null) {
            return Result.error("公告不存在");
        }
        return Result.success(notice);
    }

    @PostMapping
    public Result<String> addNotice(@RequestBody Notice notice) {
        // 如果设置为置顶，先取消其他所有公告的置顶
        if (notice.getIsTop() != null && notice.getIsTop() == 1) {
            noticeMapper.update(null, 
                new LambdaUpdateWrapper<Notice>()
                    .set(Notice::getIsTop, 0)
                    .eq(Notice::getIsTop, 1)
            );
        }
        
        notice.setPublishTime(LocalDateTime.now());
        notice.setCreateTime(LocalDateTime.now());
        notice.setDeleted(0);
        notice.setAdminId(1L);
        noticeMapper.insert(notice);
        return Result.success("发布成功");
    }

    @PutMapping
    public Result<String> updateNotice(@RequestBody Notice notice) {
        Notice existingNotice = noticeMapper.selectById(notice.getId());
        if (existingNotice == null) {
            return Result.error("公告不存在");
        }

        // 如果设置为置顶，先取消其他所有公告的置顶（排除自己）
        if (notice.getIsTop() != null && notice.getIsTop() == 1) {
            noticeMapper.update(null, 
                new LambdaUpdateWrapper<Notice>()
                    .set(Notice::getIsTop, 0)
                    .eq(Notice::getIsTop, 1)
                    .ne(Notice::getId, notice.getId())
            );
        }

        existingNotice.setTitle(notice.getTitle());
        existingNotice.setContent(notice.getContent());
        existingNotice.setIsTop(notice.getIsTop());
        existingNotice.setPublishTime(LocalDateTime.now());

        noticeMapper.updateById(existingNotice);
        return Result.success("更新成功");
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteNotice(@PathVariable Long id) {
        noticeMapper.deleteById(id);
        return Result.success("删除成功");
    }
}
