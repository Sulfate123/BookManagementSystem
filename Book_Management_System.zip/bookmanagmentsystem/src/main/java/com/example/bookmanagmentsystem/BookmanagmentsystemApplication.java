package com.example.bookmanagmentsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookmanagmentsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookmanagmentsystemApplication.class, args);
    }

}
