USE book_management;
-- 修改字段长度
ALTER TABLE admin MODIFY COLUMN password VARCHAR(255) NOT NULL COMMENT '密码';

-- 重新设置密码
UPDATE admin
SET password = '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa'
WHERE username = 'admin';

-- 再次验证
SELECT id, username, LENGTH(password) as password_length, password FROM admin WHERE username = 'admin';
