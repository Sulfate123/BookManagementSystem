-- ============================================
-- 书香图书管理系统 - 数据库初始化脚本
-- 数据库: book_management
-- MySQL 8.0+
-- ============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS book_management 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE book_management;

-- ============================================
-- 1. 管理员表
-- ============================================
CREATE TABLE IF NOT EXISTS admin (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '管理员ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '账号',
    password VARCHAR(255) NOT NULL COMMENT '密码(BCrypt加密)',
    real_name VARCHAR(50) COMMENT '姓名',
    phone VARCHAR(20) COMMENT '手机号',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    status INT DEFAULT 1 COMMENT '账号状态：0-禁用，1-启用',
    deleted INT DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ============================================
-- 2. 读者用户表
-- ============================================
CREATE TABLE IF NOT EXISTS reader (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '读者ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '账号',
    password VARCHAR(255) NOT NULL COMMENT '密码(BCrypt加密)',
    real_name VARCHAR(50) COMMENT '姓名',
    avatar VARCHAR(255) COMMENT '头像URL',
    phone VARCHAR(20) COMMENT '联系方式',
    student_number VARCHAR(50) COMMENT '学号/工号',
    max_borrow_count INT DEFAULT 5 COMMENT '可借阅数量',
    current_borrow_count INT DEFAULT 0 COMMENT '当前借阅数量',
    overdue_status INT DEFAULT 0 COMMENT '逾期状态：0-无逾期，1-有逾期',
    register_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
    deleted INT DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='读者用户表';

-- ============================================
-- 3. 图书分类表
-- ============================================
CREATE TABLE IF NOT EXISTS book_category (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '分类ID',
    category_name VARCHAR(100) NOT NULL COMMENT '分类名称',
    parent_id BIGINT DEFAULT 0 COMMENT '父级分类ID',
    sort_order INT DEFAULT 0 COMMENT '排序序号',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    deleted INT DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书分类表';

-- ============================================
-- 4. 图书信息表
-- ============================================
CREATE TABLE IF NOT EXISTS book (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '图书ID',
    book_name VARCHAR(200) NOT NULL COMMENT '书名',
    author VARCHAR(100) COMMENT '作者',
    publisher VARCHAR(100) COMMENT '出版社',
    isbn VARCHAR(20) COMMENT 'ISBN',
    publish_date DATE COMMENT '出版时间',
    category_id BIGINT COMMENT '分类ID',
    cover_image VARCHAR(255) COMMENT '封面地址',
    introduction TEXT COMMENT '图书简介',
    total_stock INT DEFAULT 0 COMMENT '总库存',
    available_stock INT DEFAULT 0 COMMENT '剩余可借数量',
    price DECIMAL(10,2) COMMENT '图书单价',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    deleted INT DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
    INDEX idx_category_id (category_id),
    INDEX idx_isbn (isbn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书信息表';

-- ============================================
-- 5. 借阅记录表
-- ============================================
CREATE TABLE IF NOT EXISTS borrow_record (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
    reader_id BIGINT NOT NULL COMMENT '读者ID',
    book_id BIGINT NOT NULL COMMENT '图书ID',
    borrow_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '借书时间',
    due_time DATETIME COMMENT '应还时间',
    expected_return_time DATETIME COMMENT '预计归还时间',
    return_time DATETIME COMMENT '实际还书时间',
    renew_count INT DEFAULT 0 COMMENT '续借次数',
    overdue_days INT DEFAULT 0 COMMENT '逾期天数',
    fine_amount DECIMAL(10,2) DEFAULT 0.00 COMMENT '罚金金额',
    status INT DEFAULT 0 COMMENT '借阅状态：0-在借，1-已还，2-逾期',
    INDEX idx_reader_id (reader_id),
    INDEX idx_book_id (book_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='借阅记录表';

-- ============================================
-- 6. 公告表
-- ============================================
CREATE TABLE IF NOT EXISTS notice (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '公告ID',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT COMMENT '内容',
    publish_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    is_top INT DEFAULT 0 COMMENT '置顶状态：0-不置顶，1-置顶',
    expire_time DATETIME COMMENT '过期时间',
    admin_id BIGINT COMMENT '发布管理员ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    deleted INT DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公告表';

-- ============================================
-- 7. 聊天历史表（AI助手）
-- ============================================
CREATE TABLE IF NOT EXISTS chat_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '聊天记录ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    role VARCHAR(20) NOT NULL COMMENT '角色：user/assistant',
    message TEXT NOT NULL COMMENT '消息内容',
    message_type VARCHAR(50) DEFAULT 'text' COMMENT '消息类型',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_id (user_id),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天历史记录表';

-- ============================================
-- 插入初始数据
-- ============================================

-- 1. 插入默认管理员账号（密码：admin123）
-- BCrypt哈希值对应明文密码 admin123
INSERT INTO admin (username, password, real_name, phone, status) VALUES
('admin', '$2a$10$gBD5/UAWtAARnfBubkrlr.JvH6nGGM9gZLK7hTtg5lNT1jNpacYNy', '系统管理员', '13800138000', 1);

-- 2. 插入图书分类数据
INSERT INTO book_category (category_name, parent_id, sort_order) VALUES
('文学', 0, 1),
('科技', 0, 2),
('历史', 0, 3),
('哲学', 0, 4),
('艺术', 0, 5),
('中国文学', 1, 1),
('外国文学', 1, 2),
('计算机科学', 2, 1),
('自然科学', 2, 2);

-- 3. 插入示例图书数据
INSERT INTO book (book_name, author, publisher, isbn, publish_date, category_id, introduction, total_stock, available_stock, price) VALUES
('红楼梦', '曹雪芹', '人民文学出版社', '9787020002207', '2008-07-01', 6, '中国古典小说四大名著之一，以贾宝玉、林黛玉的爱情悲剧为主线，展现了封建社会的兴衰历程。', 5, 5, 59.80),
('三国演义', '罗贯中', '人民文学出版社', '9787020008187', '2010-01-01', 6, '中国第一部长篇章回体历史演义小说，描写了东汉末年到西晋初年的历史风云。', 4, 4, 49.50),
('Java核心技术', '凯.S.霍斯特曼', '机械工业出版社', '9787111543647', '2016-09-01', 8, 'Java领域最具权威的经典著作，全面介绍Java语言的核心特性。', 3, 3, 119.00),
('百年孤独', '加西亚·马尔克斯', '南海出版公司', '9787544253994', '2011-06-01', 7, '魔幻现实主义文学代表作，讲述了布恩迪亚家族七代人的传奇故事。', 6, 6, 39.50),
('西游记', '吴承恩', '人民文学出版社', '9787020008194', '2010-01-01', 6, '中国古代第一部浪漫主义章回体长篇神魔小说。', 5, 5, 45.00),
('水浒传', '施耐庵', '人民文学出版社', '9787020008201', '2010-01-01', 6, '中国历史上第一部用白话文写成的章回小说。', 4, 4, 52.00),
('深入理解计算机系统', '兰德尔·E.布莱恩特', '机械工业出版社', '9787111544937', '2016-09-01', 8, '计算机科学经典教材，从程序员角度深入理解计算机系统。', 2, 2, 139.00),
('人类简史', '尤瓦尔·赫拉利', '中信出版社', '9787508646693', '2014-11-01', 3, '从认知革命到科学革命，梳理人类发展历史。', 7, 7, 68.00);

-- ============================================
-- 验证数据
-- ============================================
SELECT '数据库初始化完成！' AS message;
SELECT CONCAT('管理员账号: ', username, ' / 密码: admin123') AS admin_info FROM admin WHERE username = 'admin';
SELECT COUNT(*) AS category_count FROM book_category;
SELECT COUNT(*) AS book_count FROM book;
