class AIAssistant {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.userInfo = JSON.parse(sessionStorage.getItem('userInfo') || '{}');
        
        if (!this.userInfo.role) {
            this.userInfo.userId = 0;
            this.userInfo.role = 'reader';
            this.userInfo.username = '游客';
        }
        
        this.init();
    }
    
    init() {
        this.createWidget();
        this.bindEvents();
    }
    
    createWidget() {
        const container = document.createElement('div');
        container.className = 'ai-assistant-container';
        
        const isAdmin = this.userInfo.role === 'admin';
        const isLoggedIn = this.userInfo.userId > 0;
        
        container.innerHTML = `
            <div class="ai-chat-window" id="aiChatWindow">
                <div class="ai-chat-header">
                    <h3>📚 小书童 ${isAdmin ? '(管理员)' : ''}</h3>
                    <div class="header-actions">
                        <button class="ai-close-btn" id="aiCloseBtn">&times;</button>
                    </div>
                </div>
                <div class="ai-chat-messages" id="aiMessages"></div>
                <div class="ai-input-area">
                    <input type="text" id="aiInput" placeholder="输入您的问题..." />
                    <button class="ai-send-btn" id="aiSendBtn">➤</button>
                </div>
            </div>
            <button class="ai-float-button" id="aiFloatBtn">💬</button>
        `;
        
        document.body.appendChild(container);
    }
    
    bindEvents() {
        document.getElementById('aiFloatBtn').addEventListener('click', () => this.toggleChat());
        document.getElementById('aiCloseBtn').addEventListener('click', () => this.closeChat());
        document.getElementById('aiSendBtn').addEventListener('click', () => this.sendMessage());
        document.getElementById('aiInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });
    }
    
    async loadHistory() {
        if (!this.userInfo.userId || this.userInfo.userId <= 0) return;
        
        try {
            console.log('加载AI历史，userId:', this.userInfo.userId);
            const response = await fetch(`/api/ai/history/${this.userInfo.userId}`);
            
            if (!response.ok) {
                console.warn('历史记录接口返回:', response.status, response.statusText);
                if (response.status === 403) {
                    console.warn('历史记录接口被禁止访问，可能是权限问题');
                }
                return;
            }
            
            const result = await response.json();
            console.log('历史记录响应:', result);
            
            if (result.code === 200 && result.data && result.data.length > 0) {
                console.log('加载了', result.data.length, '条历史记录');
                result.data.forEach(msg => {
                    this.addMessage(msg.message, msg.role, false);
                });
            } else {
                console.log('没有历史记录');
            }
        } catch (error) {
            console.error('加载历史失败:', error);
        }
    }
    
    async clearHistory() {
        if (!this.userInfo.userId || this.userInfo.userId <= 0) return;
        if (!confirm('确定要清除所有聊天记录吗？')) return;
        
        try {
            const response = await fetch(`/api/ai/history/${this.userInfo.userId}`, {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (result.code === 200) {
                this.messages = [];
                document.getElementById('aiMessages').innerHTML = '';
                this.addWelcomeMessage();
            }
        } catch (error) {
            console.error('清除历史失败:', error);
        }
    }
    
    toggleChat() {
        if (this.isOpen) {
            this.closeChat();
        } else {
            this.openChat();
        }
    }
    
    openChat() {
        document.getElementById('aiChatWindow').classList.add('show');
        document.getElementById('aiFloatBtn').style.display = 'none';
        this.isOpen = true;
        
        if (this.messages.length === 0) {
            this.addWelcomeMessage();
        }
    }
    
    closeChat() {
        document.getElementById('aiChatWindow').classList.remove('show');
        document.getElementById('aiFloatBtn').style.display = 'flex';
        this.isOpen = false;
    }
    
    addWelcomeMessage() {
        const isLoggedIn = this.userInfo.userId > 0;
        const roleText = this.userInfo.role === 'admin' ? '管理员' : (isLoggedIn ? '读者' : '游客');
        
        let welcomeMsg = `您好！我是小书童 📚，您的智能图书助手。\n\n`;
        welcomeMsg += `当前身份：${roleText}\n\n`;
        welcomeMsg += `我可以帮您：\n`;
        welcomeMsg += `• 查询图书信息（无需登录）\n`;
        welcomeMsg += `• 浏览热门和新书推荐\n`;
        welcomeMsg += `• 回答图书相关问题\n\n`;
        
        if (!isLoggedIn) {
            welcomeMsg += `💡 提示：登录后还可以：\n`;
            welcomeMsg += `• 借阅图书\n`;
            welcomeMsg += `• 查看个人借阅记录\n`;
            welcomeMsg += `• 续借和还书\n\n`;
        }
        
        if (this.userInfo.role === 'admin') {
            welcomeMsg += `🔧 管理员专属功能：\n`;
            welcomeMsg += `• 查看系统统计\n`;
            welcomeMsg += `• 查看所有图书列表\n`;
            welcomeMsg += `• 图书管理（添加/编辑/删除）\n`;
            welcomeMsg += `• 读者管理（查看/编辑/删除）\n`;
            welcomeMsg += `• 公告管理（发布/编辑/删除）\n`;
            welcomeMsg += `• 借阅管理（查看/归还）\n\n`;
        }
        
        welcomeMsg += `💡 提示：单次输入最多200字\n\n`;
        welcomeMsg += `请问有什么可以帮您的吗？`;
        
        this.addMessage(welcomeMsg, 'assistant');
    }
    
    async sendMessage() {
        const input = document.getElementById('aiInput');
        const message = input.value.trim();
        
        if (!message) return;
        
        this.addMessage(message, 'user', true);
        input.value = '';
        
        this.showTyping();
        
        console.log('发送消息:', message);
        console.log('用户信息:', this.userInfo);
        
        try {
            const requestBody = {
                message: message,
                userId: this.userInfo.userId && this.userInfo.userId > 0 ? this.userInfo.userId : null,
                role: this.userInfo.role || 'reader'
            };
            
            console.log('请求体:', requestBody);
            
            const response = await fetch('/api/ai/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            console.log('响应状态:', response.status);
            console.log('Content-Type:', response.headers.get('Content-Type'));
            
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let receivedFirstChunk = false;
            let streamingDiv = null;
            let streamContent = '';
            
            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    console.log('流式读取完成');
                    if (buffer.trim()) {
                        const trimmedLine = buffer.trim();
                        if (trimmedLine.startsWith('data:')) {
                            const data = trimmedLine.startsWith('data: ') 
                                ? trimmedLine.slice(6).trim() 
                                : trimmedLine.slice(5).trim();
                            
                            if (data && data !== '[DONE]') {
                                try {
                                    const result = JSON.parse(data);
                                    if (!receivedFirstChunk) {
                                        this.hideTyping();
                                        receivedFirstChunk = true;
                                    }
                                    if (result.code === 200) {
                                        if (result.streaming) {
                                            streamContent += result.reply;
                                            if (streamingDiv) {
                                                this.updateStreamingMessage(streamingDiv, streamContent);
                                            }
                                        } else {
                                            if (streamingDiv) {
                                                this.finalizeStreamingMessage(streamingDiv, streamContent);
                                            } else {
                                                this.addMessage(result.reply, 'assistant', true);
                                            }
                                            if (result.action) {
                                                this.handleAction(result.action, result.data);
                                            }
                                            streamingDiv = null;
                                            streamContent = '';
                                        }
                                    }
                                } catch (e) {
                                    console.error('解析剩余数据失败:', e);
                                }
                            }
                        }
                    }
                    if (streamingDiv && streamContent) {
                        this.finalizeStreamingMessage(streamingDiv, streamContent);
                    }
                    break;
                }
                
                const chunk = decoder.decode(value, { stream: true });
                
                buffer += chunk;
                
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    const trimmedLine = line.trim();
                    
                    if (trimmedLine.startsWith('data:')) {
                        const data = trimmedLine.startsWith('data: ') 
                            ? trimmedLine.slice(6).trim() 
                            : trimmedLine.slice(5).trim();
                        
                        if (data === '[DONE]' || data === '') {
                            continue;
                        }
                        
                        try {
                            const result = JSON.parse(data);
                            
                            if (!receivedFirstChunk) {
                                this.hideTyping();
                                receivedFirstChunk = true;
                            }
                            
                            if (result.code === 200) {
                                if (result.streaming) {
                                    streamContent += result.reply;
                                    if (!streamingDiv) {
                                        streamingDiv = this.addStreamingMessage(streamContent);
                                    } else {
                                        this.updateStreamingMessage(streamingDiv, streamContent);
                                    }
                                } else {
                                    if (streamingDiv) {
                                        this.finalizeStreamingMessage(streamingDiv, streamContent);
                                        streamingDiv = null;
                                    } else {
                                        this.addMessage(result.reply, 'assistant', true);
                                    }
                                    streamContent = '';
                                    
                                    if (result.action) {
                                        this.handleAction(result.action, result.data);
                                    }
                                }
                            } else if (result.code === 401) {
                                this.addMessage(result.reply, 'assistant');
                                setTimeout(() => {
                                    if (confirm('需要登录才能使用此功能，是否现在登录？')) {
                                        window.location.href = '/login.html';
                                    }
                                }, 1000);
                            } else {
                                this.addMessage(result.message || '抱歉，处理您的请求时出错了。', 'assistant', true);
                            }
                        } catch (e) {
                            console.error('✗ 解析JSON失败:', e);
                        }
                    }
                }
            }
            
            if (!receivedFirstChunk) {
                console.warn('未接收到任何有效数据块');
                this.hideTyping();
                this.addMessage('抱歉，AI服务没有返回响应。', 'assistant', true);
            }
            
        } catch (error) {
            console.error('✗ AI请求失败:', error);
            this.hideTyping();
            this.addMessage('网络错误，请稍后重试。', 'assistant', true);
        }
    }
    
    addMessage(content, type, saveToServer = false) {
        const messagesContainer = document.getElementById('aiMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ${type}`;
        
        const time = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
        
        messageDiv.innerHTML = `
            <div class="ai-message-content">${this.formatMessage(content)}</div>
            <div class="ai-message-time">${time}</div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        this.messages.push({ content, type, time });
        return messageDiv;
    }
    
    addStreamingMessage(content) {
        const messagesContainer = document.getElementById('aiMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-message assistant streaming';
        
        messageDiv.innerHTML = `
            <div class="ai-message-content">${this.formatMessage(content)}<span class="streaming-cursor">▌</span></div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        return messageDiv;
    }
    
    updateStreamingMessage(messageDiv, content) {
        const contentDiv = messageDiv.querySelector('.ai-message-content');
        if (contentDiv) {
            contentDiv.innerHTML = `${this.formatMessage(content)}<span class="streaming-cursor">▌</span>`;
        }
        const messagesContainer = document.getElementById('aiMessages');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    finalizeStreamingMessage(messageDiv, content) {
        const time = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
        messageDiv.classList.remove('streaming');
        messageDiv.innerHTML = `
            <div class="ai-message-content">${this.formatMessage(content)}</div>
            <div class="ai-message-time">${time}</div>
        `;
        this.messages.push({ content, type: 'assistant', time });
    }
    
    formatMessage(content) {
        return content.replace(/\n/g, '<br>');
    }
    
    showTyping() {
        const messagesContainer = document.getElementById('aiMessages');
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-message assistant';
        typingDiv.id = 'aiTyping';
        typingDiv.innerHTML = `
            <div class="ai-message-content">
                <div class="ai-typing">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    hideTyping() {
        const typing = document.getElementById('aiTyping');
        if (typing) {
            typing.remove();
        }
    }
    
    handleAction(action, data) {
        if (action === 'show_books' || action === 'show_all_books') {
            this.showBooksList(data);
        } else if (action === 'show_borrow_records') {
            this.showBorrowRecords(data);
        } else if (action === 'show_statistics') {
            this.showStatistics(data);
        } else if (action === 'borrow_book') {
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else if (action === 'switch_books') {
            this.switchAdminSection('books');
        } else if (action === 'switch_readers') {
            this.switchAdminSection('readers');
        } else if (action === 'switch_notices') {
            this.switchAdminSection('notices');
        } else if (action === 'switch_borrows') {
            this.switchAdminSection('borrows');
        } else if (action === 'add_book') {
            this.switchAdminSection('books');
            setTimeout(() => {
                if (typeof showAddBookModal === 'function') {
                    showAddBookModal();
                }
            }, 300);
        } else if (action === 'add_notice') {
            this.switchAdminSection('notices');
            setTimeout(() => {
                if (typeof showAddNoticeModal === 'function') {
                    showAddNoticeModal();
                }
            }, 300);
        } else if (action === 'open_book_modal') {
            this.switchAdminSection('books');
        }
    }
    
    switchAdminSection(sectionId) {
        const sectionLinks = document.querySelectorAll('.admin-sidebar nav a');
        const sections = document.querySelectorAll('.admin-section');
        
        sections.forEach(s => s.classList.remove('active'));
        sectionLinks.forEach(a => a.classList.remove('active'));
        
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }
        
        sectionLinks.forEach(link => {
            const onclick = link.getAttribute('onclick');
            if (onclick && onclick.includes(`'${sectionId}'`)) {
                link.classList.add('active');
            }
        });
        
        if (sectionId === 'books' && typeof loadBooks === 'function') {
            loadBooks();
        } else if (sectionId === 'readers' && typeof loadReaders === 'function') {
            loadReaders();
        } else if (sectionId === 'notices' && typeof loadNotices === 'function') {
            loadNotices();
        } else if (sectionId === 'borrows' && typeof loadBorrows === 'function') {
            loadBorrows();
        }
    }
    
    showBooksList(books) {
        if (!books || books.length === 0) return;
        
        const messagesContainer = document.getElementById('aiMessages');
        const booksDiv = document.createElement('div');
        booksDiv.className = 'ai-message assistant';
        
        const isLoggedIn = this.userInfo.userId > 0;
        
        const booksHtml = books.map(book => `
            <div class="ai-book-item" onclick="aiAssistant.borrowBookById(${book.id})">
                <div class="ai-book-title">${book.bookName}</div>
                <div class="ai-book-info">作者：${book.author || '未知'}</div>
                <div class="ai-book-info">出版社：${book.publisher || '未知'}</div>
                <div class="ai-book-info">库存：${book.availableStock}/${book.totalStock}</div>
                ${isLoggedIn ? '<div class="ai-book-info">点击即可借阅 📖</div>' : '<div class="ai-book-info">登录后即可借阅 🔐</div>'}
            </div>
        `).join('');
        
        booksDiv.innerHTML = `
            <div class="ai-message-content">
                <div class="ai-books-grid">${booksHtml}</div>
            </div>
        `;
        
        messagesContainer.appendChild(booksDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    showBorrowRecords(records) {
        if (!records || records.length === 0) return;
        
        const messagesContainer = document.getElementById('aiMessages');
        const recordsDiv = document.createElement('div');
        recordsDiv.className = 'ai-message assistant';
        
        const recordsHtml = records.map(record => {
            const status = record.status === 0 ? '在借' : '已还';
            const dueDate = new Date(record.dueTime).toLocaleDateString('zh-CN');
            return `
                <div style="padding: 8px; margin: 5px 0; background: #f5f3ee; border-radius: 6px;">
                    <div>图书ID：${record.bookId}</div>
                    <div>借书时间：${new Date(record.borrowTime).toLocaleDateString('zh-CN')}</div>
                    <div>应还时间：${dueDate}</div>
                    <div>状态：${status}</div>
                </div>
            `;
        }).join('');
        
        recordsDiv.innerHTML = `
            <div class="ai-message-content">
                ${recordsHtml}
            </div>
        `;
        
        messagesContainer.appendChild(recordsDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    showStatistics(stats) {
        const messagesContainer = document.getElementById('aiMessages');
        const statsDiv = document.createElement('div');
        statsDiv.className = 'ai-message assistant';
        
        statsDiv.innerHTML = `
            <div class="ai-message-content">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
                    <div style="background: #f5f3ee; padding: 15px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 24px; color: #2c5f2d; font-weight: bold;">${stats.totalBooks}</div>
                        <div style="font-size: 12px; color: #666;">总图书数</div>
                    </div>
                    <div style="background: #f5f3ee; padding: 15px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 24px; color: #2c5f2d; font-weight: bold;">${stats.totalBorrows}</div>
                        <div style="font-size: 12px; color: #666;">总借阅数</div>
                    </div>
                </div>
            </div>
        `;
        
        messagesContainer.appendChild(statsDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    async borrowBookById(bookId) {
        if (!this.userInfo.userId || this.userInfo.userId <= 0) {
            this.addMessage('请先登录后再借阅图书 📚', 'assistant');
            setTimeout(() => {
                if (confirm('需要登录才能借阅图书，是否现在登录？')) {
                    window.location.href = '/login.html';
                }
            }, 1000);
            return;
        }
        
        try {
            const response = await fetch('/api/borrow', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    readerId: this.userInfo.userId,
                    bookId: bookId
                })
            });
            
            const result = await response.json();
            
            if (result.code === 200) {
                this.addMessage('✅ 借阅成功！', 'assistant');
            } else {
                this.addMessage(`❌ ${result.message}`, 'assistant');
            }
        } catch (error) {
            this.addMessage('借阅失败，请稍后重试', 'assistant');
        }
    }
}

const aiAssistant = new AIAssistant();
