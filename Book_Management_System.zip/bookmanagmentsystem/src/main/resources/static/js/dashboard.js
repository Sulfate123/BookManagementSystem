document.addEventListener('DOMContentLoaded', function() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (!userInfo) {
        window.location.href = '/login.html';
        return;
    }
    
    document.getElementById('userName').textContent = userInfo.realName || userInfo.username;
    if (userInfo.avatar) {
        document.getElementById('userAvatar').src = userInfo.avatar;
    }
    
    loadBorrowingRecords(userInfo.userId);
});

function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    
    document.getElementById(sectionId).classList.add('active');
    event.target.classList.add('active');
    
    if (sectionId === 'profile') {
        loadUserProfile();
    }
}

let isEditMode = false;
let originalData = {};
let selectedAvatarFile = null;
let originalAvatarUrl = '';

async function loadUserProfile() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    if (!userInfo || !userInfo.userId) {
        console.error('用户信息不存在');
        return;
    }
    
    try {
        console.log('加载用户信息，userId:', userInfo.userId);
        const response = await fetch(`/api/readers/${userInfo.userId}`);
        const result = await response.json();
        
        console.log('用户信息响应:', result);
        
        if (result.code === 200) {
            const reader = result.data;
            
            originalData = { ...reader };
            originalAvatarUrl = reader.avatar || '';
            
            document.getElementById('username').value = reader.username || '';
            document.getElementById('realName').value = reader.realName || '';
            document.getElementById('phone').value = reader.phone || '';
            document.getElementById('studentNumber').value = reader.studentNumber || '';
            document.getElementById('maxBorrowCount').value = reader.maxBorrowCount || 5;
            document.getElementById('currentBorrowCount').value = reader.currentBorrowCount || 0;
            document.getElementById('registerTime').value = reader.registerTime || '';
            
            const avatarSrc = reader.avatar || '/images/default-avatar.png';
            document.getElementById('userAvatar').src = avatarSrc;
            document.getElementById('profileAvatar').src = avatarSrc;
            
            disableEdit();
        } else {
            console.error('加载用户信息失败:', result.message);
        }
    } catch (error) {
        console.error('加载用户信息错误:', error);
    }
}

function enableEdit() {
    isEditMode = true;
    
    const editableFields = ['realName', 'phone', 'studentNumber'];
    
    editableFields.forEach(fieldId => {
        const input = document.getElementById(fieldId);
        if (input) {
            input.removeAttribute('readonly');
            input.removeAttribute('disabled');
            input.style.backgroundColor = '#fff';
            input.style.cursor = 'text';
            input.style.opacity = '1';
        }
    });
    
    document.getElementById('avatarInputWrap').style.display = 'block';
    document.getElementById('editProfileBtn').style.display = 'none';
    document.getElementById('formActions').style.display = 'flex';
    
    selectedAvatarFile = null;
    document.getElementById('avatarFile').value = '';
}

function disableEdit() {
    isEditMode = false;
    
    const editableFields = ['realName', 'phone', 'studentNumber'];
    const readonlyFields = ['username', 'maxBorrowCount', 'currentBorrowCount', 'registerTime'];
    
    editableFields.forEach(fieldId => {
        const input = document.getElementById(fieldId);
        if (input) {
            input.setAttribute('readonly', 'readonly');
            input.setAttribute('disabled', 'disabled');
            input.style.backgroundColor = '#f9f9f9';
            input.style.cursor = 'not-allowed';
            input.style.opacity = '0.7';
        }
    });
    
    readonlyFields.forEach(fieldId => {
        const input = document.getElementById(fieldId);
        if (input) {
            input.setAttribute('readonly', 'readonly');
            input.setAttribute('disabled', 'disabled');
        }
    });
    
    document.getElementById('avatarInputWrap').style.display = 'none';
    document.getElementById('editProfileBtn').style.display = 'block';
    document.getElementById('formActions').style.display = 'none';
    
    selectedAvatarFile = null;
}

function cancelEdit() {
    document.getElementById('realName').value = originalData.realName || '';
    document.getElementById('phone').value = originalData.phone || '';
    document.getElementById('studentNumber').value = originalData.studentNumber || '';
    
    const avatarSrc = originalAvatarUrl || '/images/default-avatar.png';
    document.getElementById('profileAvatar').src = avatarSrc;
    document.getElementById('userAvatar').src = avatarSrc;
    
    selectedAvatarFile = null;
    document.getElementById('avatarFile').value = '';
    
    disableEdit();
}

function handleAvatarSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        alert('请选择图片文件');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        alert('图片大小不能超过5MB');
        return;
    }
    
    selectedAvatarFile = file;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('profileAvatar').src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function clearAvatarSelection() {
    selectedAvatarFile = null;
    document.getElementById('avatarFile').value = '';
    
    const avatarSrc = originalAvatarUrl || '/images/default-avatar.png';
    document.getElementById('profileAvatar').src = avatarSrc;
}

async function loadBorrowingRecords(readerId) {
    try {
        const response = await fetch(`/api/borrow/reader/${readerId}`);
        const result = await response.json();
        
        if (result.code === 200) {
            const borrowingList = document.getElementById('borrowingList');
            const historyList = document.getElementById('historyList');
            const overdueList = document.getElementById('overdueList');
            
            const borrowing = result.data.filter(r => r.status === 0);
            const returned = result.data.filter(r => r.status === 1);
            const overdue = result.data.filter(r => r.status === 2 || (r.status === 0 && new Date(r.dueTime) < new Date()));
            
            borrowingList.innerHTML = borrowing.length > 0 
                ? borrowing.map(record => createRecordCard(record, true)).join('')
                : '<p>暂无在借图书</p>';
            
            historyList.innerHTML = returned.length > 0
                ? returned.map(record => createRecordCard(record, false)).join('')
                : '<p>暂无借阅历史</p>';
            
            overdueList.innerHTML = overdue.length > 0
                ? overdue.map(record => createRecordCard(record, true, true)).join('')
                : '<p>暂无逾期记录</p>';
        }
    } catch (error) {
        console.error('加载借阅记录失败:', error);
    }
}

function createRecordCard(record, showActions, isOverdue = false) {
    const dueDate = new Date(record.dueTime);
    const daysLeft = Math.ceil((dueDate - new Date()) / (1000 * 60 * 60 * 24));
    
    return `
        <div class="borrow-record ${isOverdue ? 'overdue' : ''}">
            <div class="record-info">
                <div>
                    <strong>${record.bookName || '未知图书'}</strong>
                    <p>借书时间：${formatDate(record.borrowTime)}</p>
                    <p>应还时间：${formatDate(record.dueTime)}</p>
                    ${record.returnTime ? `<p>归还时间：${formatDate(record.returnTime)}</p>` : ''}
                    ${isOverdue ? `<p style="color:#c44536;">剩余天数：${daysLeft}天（已逾期）</p>` : `<p>剩余天数：${daysLeft}天</p>`}
                    ${record.fineAmount > 0 ? `<p style="color:#c44536;">罚金：¥${record.fineAmount}</p>` : ''}
                </div>
            </div>
            ${showActions && record.status === 0 ? `
                <div class="record-actions">
                    <button class="btn-small btn-renew" onclick="renewBook(${record.id})">续借</button>
                </div>
            ` : ''}
        </div>
    `;
}

async function renewBook(recordId) {
    if (!confirm('确认续借此图书？')) return;
    
    try {
        const response = await fetch(`/api/borrow/renew/${recordId}`, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.code === 200) {
            alert('续借成功！');
            const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
            loadBorrowingRecords(userInfo.userId);
        } else {
            alert(result.message || '续借失败');
        }
    } catch (error) {
        console.error('续借错误:', error);
        alert('网络错误，请稍后重试');
    }
}

document.getElementById('profileForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    if (!userInfo || !userInfo.userId) {
        alert('请先登录');
        return;
    }
    
    let avatarUrl = originalAvatarUrl;
    
    if (selectedAvatarFile) {
        try {
            avatarUrl = await uploadAvatar(selectedAvatarFile);
        } catch (error) {
            console.error('头像上传失败:', error);
            alert('头像上传失败，请稍后重试');
            return;
        }
    }
    
    const readerData = {
        id: userInfo.userId,
        realName: document.getElementById('realName').value,
        phone: document.getElementById('phone').value,
        studentNumber: document.getElementById('studentNumber').value,
        avatar: avatarUrl || null
    };
    
    try {
        const response = await fetch('/api/readers', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(readerData)
        });
        
        const result = await response.json();
        
        if (result.code === 200) {
            alert('✅ 保存成功！');
            
            userInfo.realName = readerData.realName;
            if (readerData.avatar) {
                userInfo.avatar = readerData.avatar;
            }
            sessionStorage.setItem('userInfo', JSON.stringify(userInfo));
            document.getElementById('userName').textContent = readerData.realName || userInfo.username;
            
            const avatarSrc = readerData.avatar || '/images/default-avatar.png';
            document.getElementById('userAvatar').src = avatarSrc;
            document.getElementById('profileAvatar').src = avatarSrc;
            
            originalData.realName = readerData.realName;
            originalData.phone = readerData.phone;
            originalData.studentNumber = readerData.studentNumber;
            originalAvatarUrl = readerData.avatar || '';
            
            disableEdit();
        } else {
            alert('❌ ' + (result.message || '保存失败'));
        }
    } catch (error) {
        console.error('保存错误:', error);
        alert('❌ 网络错误，请稍后重试');
    }
});

async function uploadAvatar(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData
    });
    
    if (!response.ok) {
        throw new Error('上传失败');
    }
    
    const result = await response.json();
    
    if (result.code !== 200) {
        throw new Error(result.message || '上传失败');
    }
    
    return result.data;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });
}

function logout() {
    sessionStorage.clear();
    window.location.href = '/';
}
