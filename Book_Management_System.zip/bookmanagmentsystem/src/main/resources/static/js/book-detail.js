let bookId = null;
let bookInfo = null;

document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
    
    const urlParams = new URLSearchParams(window.location.search);
    bookId = urlParams.get('id');
    
    if (!bookId) {
        alert('无效的图书ID');
        window.location.href = '/books.html';
        return;
    }
    
    loadBookDetail();
});

function checkLoginStatus() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (userInfo && userInfo.token) {
        const loginLink = document.getElementById('loginLink');
        const registerLink = document.getElementById('registerLink');
        
        if (loginLink) loginLink.style.display = 'none';
        if (registerLink) registerLink.style.display = 'none';
        
        const avatarMenu = document.getElementById('userAvatarMenu');
        if (avatarMenu) {
            avatarMenu.style.display = 'block';
            
            const avatarImg = document.getElementById('navUserAvatar');
            if (userInfo.avatar) {
                avatarImg.src = userInfo.avatar;
            } else {
                avatarImg.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23667eea" width="100" height="100"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="40">👤</text></svg>';
            }
            
            avatarImg.title = userInfo.realName || userInfo.username;
        }
    }
}

function goToDashboard() {
    window.location.href = '/dashboard.html';
}

async function loadBookDetail() {
    try {
        const response = await fetch(`/api/books/${bookId}`);
        const result = await response.json();

        if (result.code === 200) {
            bookInfo = result.data;
            displayBookDetail(bookInfo);
        } else {
            alert(result.message || '加载失败');
        }
    } catch (error) {
        console.error('加载图书详情失败:', error);
        alert('网络错误，请稍后重试');
    }
}

function displayBookDetail(book) {
    document.getElementById('bookName').textContent = book.bookName || '未知书名';
    document.getElementById('bookAuthor').textContent = book.author || '未知';
    document.getElementById('bookPublisher').textContent = book.publisher || '未知';
    document.getElementById('bookIsbn').textContent = book.isbn || '-';
    document.getElementById('bookPublishDate').textContent = book.publishDate || '-';
    document.getElementById('bookPrice').textContent = book.price ? `¥${book.price}` : '-';
    document.getElementById('bookIntroduction').textContent = book.introduction || '暂无简介';

    const stockElement = document.getElementById('bookStock');
    stockElement.textContent = `${book.availableStock}/${book.totalStock}`;

    if (book.availableStock <= 0) {
        stockElement.style.color = '#f5576c';
        stockElement.textContent += ' (已售罄)';
    } else if (book.availableStock < 3) {
        stockElement.style.color = '#ffa502';
        stockElement.textContent += ' (库存紧张)';
    } else {
        stockElement.style.color = '#667eea';
    }

    if (book.coverImage) {
        document.getElementById('bookCover').src = book.coverImage;
    } else {
        document.getElementById('bookCover').src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400"><rect fill="%23667eea" width="300" height="400"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="24">📖</text></svg>';
    }

    loadCategoryName(book.categoryId);
}

async function loadCategoryName(categoryId) {
    if (!categoryId) {
        document.getElementById('bookCategory').textContent = '未分类';
        return;
    }

    try {
        const response = await fetch(`/api/categories/${categoryId}`);
        const result = await response.json();

        if (result.code === 200) {
            document.getElementById('bookCategory').textContent = result.data.categoryName || '未分类';
        } else {
            document.getElementById('bookCategory').textContent = '未分类';
        }
    } catch (error) {
        document.getElementById('bookCategory').textContent = '未分类';
    }
}

async function showBorrowModal() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (!userInfo || !userInfo.token) {
        alert('请先登录');
        window.location.href = '/login.html';
        return;
    }
    
    if (!bookInfo) return;

    if (bookInfo.availableStock <= 0) {
        alert('该书库存不足，无法借阅');
        return;
    }

    document.getElementById('borrowBookName').value = bookInfo.bookName;
    document.getElementById('borrowReaderName').value = userInfo.realName || userInfo.username;

    const now = new Date();
    const borrowTimeStr = now.getFullYear() + '-' +
                         String(now.getMonth() + 1).padStart(2, '0') + '-' +
                         String(now.getDate()).padStart(2, '0');
    document.getElementById('borrowTime').value = borrowTimeStr;

    const defaultReturnDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const returnTimeStr = defaultReturnDate.getFullYear() + '-' +
                         String(defaultReturnDate.getMonth() + 1).padStart(2, '0') + '-' +
                         String(defaultReturnDate.getDate()).padStart(2, '0');
    document.getElementById('expectedReturnTime').value = returnTimeStr;
    document.getElementById('expectedReturnTime').min = borrowTimeStr;

    document.getElementById('borrowModal').classList.add('show');
}

function closeBorrowModal() {
    document.getElementById('borrowModal').classList.remove('show');
}

document.getElementById('borrowForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (!userInfo || !userInfo.token) {
        alert('请先登录');
        window.location.href = '/login.html';
        return;
    }
    
    const expectedReturnTime = document.getElementById('expectedReturnTime').value;

    if (!expectedReturnTime) {
        alert('请选择预计归还时间');
        return;
    }

    const returnDate = new Date(expectedReturnTime);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (returnDate < today) {
        alert('预计归还时间不能早于今天');
        return;
    }

    try {
        const response = await fetch('/api/borrow', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                readerId: userInfo.userId,
                bookId: bookId,
                expectedReturnTime: expectedReturnTime
            })
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 借阅成功！\n\n请在个人中心查看借阅记录');
            closeBorrowModal();

            setTimeout(() => {
                loadBookDetail();
            }, 500);
        } else {
            alert('❌ ' + (result.message || '借阅失败'));
        }
    } catch (error) {
        console.error('借阅错误:', error);
        alert('网络错误，请稍后重试');
    }
});

function collectBook() {
    alert('⭐ 收藏功能开发中...');
}

function goBack() {
    window.history.back();
}
