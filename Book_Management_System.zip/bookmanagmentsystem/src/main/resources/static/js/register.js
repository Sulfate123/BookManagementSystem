document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const phone = document.getElementById('phone').value.trim();
    const phoneValidation = validatePhone(phone);
    if (!phoneValidation.valid) {
        showPhoneError(phoneValidation.message);
        return;
    }

    const reader = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        realName: document.getElementById('realName').value,
        phone: phone,
        studentNumber: document.getElementById('studentNumber').value
    };

    try {
        const response = await fetch('/api/auth/reader/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(reader)
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('注册成功！请登录');
            window.location.href = '/login.html';
        } else {
            alert(result.message || '注册失败');
        }
    } catch (error) {
        console.error('注册错误:', error);
        alert('网络错误，请稍后重试');
    }
});

function validatePhone(phone) {
    if (!phone || phone.trim() === '') {
        return { valid: false, message: '手机号不能为空' };
    }
    if (!/^1[3-9]\d{9}$/.test(phone)) {
        return { valid: false, message: '请输入正确的11位手机号' };
    }
    return { valid: true, message: '' };
}

function showPhoneError(message) {
    let errorElement = document.getElementById('phoneError');
    if (!errorElement) {
        const phoneGroup = document.getElementById('phone').closest('.form-group');
        errorElement = document.createElement('div');
        errorElement.id = 'phoneError';
        errorElement.className = 'field-error';
        phoneGroup.appendChild(errorElement);
    }
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    document.getElementById('phone').style.borderColor = '#e74c3c';
}

function clearPhoneError() {
    const errorElement = document.getElementById('phoneError');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
    document.getElementById('phone').style.borderColor = '';
}

document.getElementById('phone').addEventListener('input', function() {
    clearPhoneError();
});
