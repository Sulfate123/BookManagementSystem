const API_BASE = '/api';

document.addEventListener('DOMContentLoaded', function() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));

    if (!userInfo || userInfo.role !== 'admin') {
        window.location.href = '/login.html';
        return;
    }

    loadBooks();
});

function showAdminSection(sectionId) {
    document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.admin-sidebar nav a').forEach(a => a.classList.remove('active'));

    document.getElementById(sectionId).classList.add('active');
    event.target.classList.add('active');

    switch(sectionId) {
        case 'books':
            loadBooks();
            break;
        case 'categories':
            loadCategories();
            break;
        case 'readers':
            loadReaders();
            break;
        case 'borrows':
            loadBorrows();
            break;
        case 'notices':
            loadNotices();
            break;
        case 'statistics':
            loadStatistics();
            break;
    }
}

// ==================== 图书管理 ====================
async function loadBooks() {
    try {
        const response = await fetch(`${API_BASE}/books/all`);
        const result = await response.json();

        if (result.code === 200) {
            const tbody = document.getElementById('booksTable');
            tbody.innerHTML = result.data.map(book => `
                <tr>
                    <td>${book.id}</td>
                    <td>${book.bookName}</td>
                    <td>${book.author || '-'}</td>
                    <td>${book.publisher || '-'}</td>
                    <td>${book.isbn || '-'}</td>
                    <td>${book.availableStock}/${book.totalStock}</td>
                    <td>
                        <button class="btn-small btn-edit" onclick="editBook(${book.id})">编辑</button>
                        <button class="btn-small btn-delete" onclick="deleteBook(${book.id})">删除</button>
                    </td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('加载图书失败:', error);
    }
}

async function loadCategoriesToSelect() {
    try {
        const response = await fetch(`${API_BASE}/categories`);
        const result = await response.json();

        if (result.code === 200) {
            const select = document.getElementById('bookCategory');
            select.innerHTML = '<option value="">请选择分类</option>';
            result.data.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.categoryName;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('加载分类失败:', error);
    }
}

let selectedBookCoverFile = null;
let originalBookCoverUrl = '';

function showAddBookModal() {
    document.getElementById('bookModalTitle').textContent = '添加图书';
    document.getElementById('bookForm').reset();
    document.getElementById('bookId').value = '';
    clearIsbnError();
    clearStockError();
    clearBookCoverSelection();
    loadCategoriesToSelect();
    document.getElementById('bookModal').classList.add('show');
}

function closeBookModal() {
    document.getElementById('bookModal').classList.remove('show');
    selectedBookCoverFile = null;
    originalBookCoverUrl = '';
}

async function editBook(bookId) {
    try {
        const response = await fetch(`${API_BASE}/books/${bookId}`);
        const result = await response.json();

        if (result.code === 200) {
            const book = result.data;
            document.getElementById('bookModalTitle').textContent = '编辑图书';
            document.getElementById('bookId').value = book.id;
            document.getElementById('bookName').value = book.bookName;
            document.getElementById('bookAuthor').value = book.author || '';
            document.getElementById('bookPublisher').value = book.publisher || '';
            document.getElementById('bookIsbn').value = book.isbn || '';
            document.getElementById('bookPublishDate').value = book.publishDate || '';
            document.getElementById('bookCoverImage').value = book.coverImage || '';
            document.getElementById('bookIntroduction').value = book.introduction || '';
            document.getElementById('bookPrice').value = book.price || '';
            document.getElementById('bookStock').value = book.totalStock;
            
            originalBookCoverUrl = book.coverImage || '';
            if (book.coverImage) {
                document.getElementById('bookCoverPreview').src = book.coverImage;
                document.getElementById('bookCoverPreview').style.display = 'block';
            } else {
                document.getElementById('bookCoverPreview').style.display = 'none';
            }
            
            await loadCategoriesToSelect();
            if (book.categoryId) {
                document.getElementById('bookCategory').value = book.categoryId;
            }
            
            clearIsbnError();
            clearStockError();
            selectedBookCoverFile = null;
            document.getElementById('bookCoverFile').value = '';
            document.getElementById('bookModal').classList.add('show');
        }
    } catch (error) {
        console.error('加载图书信息失败:', error);
        alert('加载图书信息失败');
    }
}

document.getElementById('bookForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const isbn = document.getElementById('bookIsbn').value.trim();
    
    const isbnValidation = validateISBN(isbn);
    if (!isbnValidation.valid) {
        showIsbnError(isbnValidation.message);
        return;
    }

    const stock = parseInt(document.getElementById('bookStock').value);
    const stockValidation = validateStock(stock);
    if (!stockValidation.valid) {
        showStockError(stockValidation.message);
        return;
    }

    let coverImageUrl = document.getElementById('bookCoverImage').value;
    
    if (selectedBookCoverFile) {
        try {
            coverImageUrl = await uploadBookCover(selectedBookCoverFile);
        } catch (error) {
            console.error('封面上传失败:', error);
            alert('封面上传失败，请稍后重试');
            return;
        }
    }

    const bookId = document.getElementById('bookId').value;
    const categoryId = document.getElementById('bookCategory').value;
    
    const bookData = {
        bookName: document.getElementById('bookName').value,
        author: document.getElementById('bookAuthor').value,
        publisher: document.getElementById('bookPublisher').value,
        isbn: isbn,
        publishDate: document.getElementById('bookPublishDate').value || null,
        categoryId: categoryId ? parseInt(categoryId) : null,
        coverImage: coverImageUrl || null,
        introduction: document.getElementById('bookIntroduction').value || null,
        price: document.getElementById('bookPrice').value ? parseFloat(document.getElementById('bookPrice').value) : null,
        totalStock: stock,
        availableStock: stock
    };

    try {
        let response;
        if (bookId) {
            response = await fetch(`${API_BASE}/books`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: parseInt(bookId), ...bookData })
            });
        } else {
            response = await fetch(`${API_BASE}/books`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookData)
            });
        }

        const result = await response.json();

        if (result.code === 200) {
            alert(bookId ? '✅ 更新成功' : '✅ 添加成功');
            closeBookModal();
            loadBooks();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('❌ 网络错误');
    }
});

async function deleteBook(bookId) {
    if (!confirm('确定要删除这本图书吗？')) return;

    try {
        const response = await fetch(`${API_BASE}/books/${bookId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 删除成功');
            loadBooks();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('❌ 网络错误');
    }
}

function handleBookCoverSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        alert('请选择图片文件');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        alert('图片大小不能超过5MB');
        return;
    }
    
    selectedBookCoverFile = file;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('bookCoverPreview').src = e.target.result;
        document.getElementById('bookCoverPreview').style.display = 'block';
    };
    reader.readAsDataURL(file);
}

function clearBookCoverSelection() {
    selectedBookCoverFile = null;
    originalBookCoverUrl = '';
    document.getElementById('bookCoverFile').value = '';
    document.getElementById('bookCoverImage').value = '';
    document.getElementById('bookCoverPreview').style.display = 'none';
}

async function uploadBookCover(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData
    });
    
    if (!response.ok) {
        throw new Error('上传失败');
    }
    
    const result = await response.json();
    
    if (result.code !== 200) {
        throw new Error(result.message || '上传失败');
    }
    
    return result.data;
}

// ==================== 分类管理 ====================
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}/categories`);
        const result = await response.json();

        if (result.code === 200) {
            const tbody = document.getElementById('categoriesTable');
            tbody.innerHTML = result.data.map(cat => `
                <tr>
                    <td>${cat.id}</td>
                    <td>${cat.categoryName}</td>
                    <td>${cat.parentId === 0 ? '-' : cat.parentId}</td>
                    <td>${cat.sortOrder}</td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('加载分类失败:', error);
    }
}

// ==================== 读者管理 ====================
async function loadReaders() {
    try {
        const response = await fetch(`${API_BASE}/readers/all`);
        const result = await response.json();

        if (result.code === 200) {
            const tbody = document.getElementById('readersTable');
            tbody.innerHTML = result.data.map(reader => `
                <tr>
                    <td>${reader.id}</td>
                    <td>${reader.username}</td>
                    <td>${reader.realName || '-'}</td>
                    <td>${reader.phone || '-'}</td>
                    <td>${reader.studentNumber || '-'}</td>
                    <td>${reader.currentBorrowCount}/${reader.maxBorrowCount}</td>
                    <td>${formatDateTime(reader.registerTime)}</td>
                    <td>
                        <button class="btn-small btn-edit" onclick="editReader(${reader.id})">编辑</button>
                        <button class="btn-small btn-delete" onclick="deleteReader(${reader.id})">删除</button>
                    </td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('加载读者失败:', error);
    }
}

function closeReaderModal() {
    document.getElementById('readerModal').classList.remove('show');
}

async function editReader(readerId) {
    try {
        const response = await fetch(`${API_BASE}/readers/${readerId}`);
        const result = await response.json();

        if (result.code === 200) {
            const reader = result.data;
            document.getElementById('readerId').value = reader.id;
            document.getElementById('readerUsername').value = reader.username;
            document.getElementById('readerRealName').value = reader.realName || '';
            document.getElementById('readerPhone').value = reader.phone || '';
            document.getElementById('readerStudentNumber').value = reader.studentNumber || '';
            document.getElementById('readerModal').classList.add('show');
        }
    } catch (error) {
        console.error('加载读者信息失败:', error);
        alert('加载读者信息失败');
    }
}

document.getElementById('readerForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const readerData = {
        id: parseInt(document.getElementById('readerId').value),
        realName: document.getElementById('readerRealName').value,
        phone: document.getElementById('readerPhone').value,
        studentNumber: document.getElementById('readerStudentNumber').value
    };

    try {
        const response = await fetch(`${API_BASE}/readers`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(readerData)
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 更新成功');
            closeReaderModal();
            loadReaders();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('❌ 网络错误');
    }
});

async function deleteReader(readerId) {
    if (!confirm('确定要删除这个读者吗？此操作不可恢复！')) return;

    try {
        const response = await fetch(`${API_BASE}/readers/${readerId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 删除成功');
            loadReaders();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('❌ 网络错误');
    }
}

// ==================== 借阅管理 ====================
async function loadBorrows() {
    try {
        const response = await fetch(`${API_BASE}/borrow/all`);
        const result = await response.json();

        if (result.code === 200) {
            const tbody = document.getElementById('borrowsTable');
            tbody.innerHTML = result.data.map(record => {
                const statusText = record.status === 0 ? '在借' : (record.status === 1 ? '已还' : '逾期');
                const statusClass = record.status === 0 ? 'status-borrowing' : (record.status === 1 ? 'status-returned' : 'status-overdue');

                return `
                    <tr>
                        <td>${record.id}</td>
                        <td>${record.readerName || '未知读者'}</td>
                        <td>${record.bookName || '未知图书'}</td>
                        <td>${formatDateTime(record.borrowTime)}</td>
                        <td>${formatDateTime(record.dueTime)}</td>
                        <td><span class="${statusClass}">${statusText}</span></td>
                        <td>
                            ${record.status === 0 ? `<button class="btn-small btn-return" onclick="returnBook(${record.id})">归还</button>` : '-'}
                        </td>
                    </tr>
                `;
            }).join('');
        }
    } catch (error) {
        console.error('加载借阅记录失败:', error);
    }
}

async function returnBook(recordId) {
    if (!confirm('确认归还此图书？')) return;

    try {
        const response = await fetch(`${API_BASE}/borrow/return/${recordId}`, {
            method: 'POST'
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 归还成功');
            loadBorrows();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('归还失败:', error);
        alert('❌ 网络错误');
    }
}

// ==================== 公告管理 ====================
async function loadNotices() {
    try {
        const response = await fetch(`${API_BASE}/notices`);
        const result = await response.json();

        if (result.code === 200) {
            const tbody = document.getElementById('noticesTable');
            tbody.innerHTML = result.data.map(notice => `
                <tr>
                    <td>${notice.id}</td>
                    <td>${notice.title}</td>
                    <td>${formatDateTime(notice.publishTime)}</td>
                    <td>${notice.isTop === 1 ? '✓' : '-'}</td>
                    <td>
                        <button class="btn-small btn-edit" onclick="editNotice(${notice.id})">编辑</button>
                        <button class="btn-small btn-delete" onclick="deleteNotice(${notice.id})">删除</button>
                    </td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('加载公告失败:', error);
    }
}

function showAddNoticeModal() {
    document.getElementById('noticeModalTitle').textContent = '发布公告';
    document.getElementById('noticeForm').reset();
    document.getElementById('noticeId').value = '';
    document.getElementById('noticeModal').classList.add('show');
}

function closeNoticeModal() {
    document.getElementById('noticeModal').classList.remove('show');
}

async function editNotice(noticeId) {
    try {
        const response = await fetch(`${API_BASE}/notices/${noticeId}`);
        const result = await response.json();

        if (result.code === 200) {
            const notice = result.data;
            document.getElementById('noticeModalTitle').textContent = '编辑公告';
            document.getElementById('noticeId').value = notice.id;
            document.getElementById('noticeTitle').value = notice.title;
            document.getElementById('noticeContent').value = notice.content;
            document.getElementById('noticeIsTop').checked = notice.isTop === 1;
            document.getElementById('noticeModal').classList.add('show');
        }
    } catch (error) {
        console.error('加载公告失败:', error);
        alert('加载公告失败');
    }
}

document.getElementById('noticeForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const noticeId = document.getElementById('noticeId').value;
    const noticeData = {
        title: document.getElementById('noticeTitle').value,
        content: document.getElementById('noticeContent').value,
        isTop: document.getElementById('noticeIsTop').checked ? 1 : 0
    };

    try {
        let response;
        if (noticeId) {
            response = await fetch(`${API_BASE}/notices`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: parseInt(noticeId), ...noticeData })
            });
        } else {
            response = await fetch(`${API_BASE}/notices`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(noticeData)
            });
        }

        const result = await response.json();

        if (result.code === 200) {
            alert(noticeId ? '✅ 更新成功' : '✅ 发布成功');
            closeNoticeModal();
            loadNotices();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('保存失败:', error);
        alert('❌ 网络错误');
    }
});

async function deleteNotice(noticeId) {
    if (!confirm('确定要删除这个公告吗？')) return;

    try {
        const response = await fetch(`${API_BASE}/notices/${noticeId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.code === 200) {
            alert('✅ 删除成功');
            loadNotices();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        console.error('删除失败:', error);
        alert('❌ 网络错误');
    }
}

// ==================== 数据统计 ====================
async function loadStatistics() {
    try {
        const response = await fetch(`${API_BASE}/statistics`);
        const result = await response.json();

        if (result.code === 200) {
            const stats = result.data;
            document.getElementById('totalBooks').textContent = stats.totalBooks || 0;
            document.getElementById('availableBooks').textContent = stats.availableBooks || 0;
            document.getElementById('borrowedBooks').textContent = stats.borrowedBooks || 0;
            document.getElementById('totalReaders').textContent = stats.totalReaders || 0;
            document.getElementById('totalBorrows').textContent = stats.totalBorrows || 0;
            document.getElementById('overdueCount').textContent = stats.overdueCount || 0;
        }
    } catch (error) {
        console.error('加载统计数据失败:', error);
    }
}

// ==================== 工具函数 ====================
function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function validateISBN(isbn) {
    if (!isbn || isbn.trim() === '') {
        return { valid: false, message: 'ISBN不能为空' };
    }
    
    const cleaned = isbn.replace(/[-\s]/g, '');
    
    if (!/^\d{13}$/.test(cleaned)) {
        return { valid: false, message: 'ISBN格式错误，应为13位数字（如：9787111234562）' };
    }
    
    if (!(cleaned.startsWith('978') || cleaned.startsWith('979'))) {
        return { valid: false, message: 'ISBN应以978或979开头' };
    }
    
    return { valid: true, message: '' };
}

function validateStock(stock) {
    const MAX_STOCK = 9999999;
    
    if (isNaN(stock) || stock < 0) {
        return { valid: false, message: '库存必须为正整数' };
    }
    
    if (stock > MAX_STOCK) {
        return { valid: false, message: `库存不能超过${MAX_STOCK}` };
    }
    
    return { valid: true, message: '' };
}

function showStockError(message) {
    let errorElement = document.getElementById('stockError');
    
    if (!errorElement) {
        const stockGroup = document.getElementById('bookStock').closest('.form-group');
        errorElement = document.createElement('div');
        errorElement.id = 'stockError';
        errorElement.className = 'field-error';
        stockGroup.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    
    document.getElementById('bookStock').style.borderColor = '#e74c3c';
}

function clearStockError() {
    const errorElement = document.getElementById('stockError');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
    document.getElementById('bookStock').style.borderColor = '#e8e4d9';
}

function showIsbnError(message) {
    let errorElement = document.getElementById('isbnError');
    
    if (!errorElement) {
        const isbnGroup = document.getElementById('bookIsbn').closest('.form-group');
        errorElement = document.createElement('div');
        errorElement.id = 'isbnError';
        errorElement.className = 'field-error';
        isbnGroup.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    
    document.getElementById('bookIsbn').style.borderColor = '#e74c3c';
}

function clearIsbnError() {
    const errorElement = document.getElementById('isbnError');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
    document.getElementById('bookIsbn').style.borderColor = '#e8e4d9';
}

document.getElementById('bookStock').addEventListener('input', function() {
    clearStockError();
});

document.getElementById('bookIsbn').addEventListener('input', function() {
    clearIsbnError();
});

function adminLogout() {
    if (confirm('确定要退出登录吗？')) {
        sessionStorage.clear();
        window.location.href = '/';
    }
}

