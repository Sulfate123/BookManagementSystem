const API_BASE = '/api';

document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
    loadHotBooks();
    loadNewBooks();
    loadAnnouncements();
});

function checkLoginStatus() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (userInfo && userInfo.token) {
        document.getElementById('loginLink').style.display = 'none';
        document.getElementById('registerLink').style.display = 'none';
        
        const avatarMenu = document.getElementById('userAvatarMenu');
        avatarMenu.style.display = 'block';
        
        const avatarImg = document.getElementById('navUserAvatar');
        if (userInfo.avatar) {
            avatarImg.src = userInfo.avatar;
        } else {
            avatarImg.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23667eea" width="100" height="100"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="40">👤</text></svg>';
        }
        
        avatarImg.title = userInfo.realName || userInfo.username;
    }
}

function goToDashboard() {
    window.location.href = '/dashboard.html';
}

async function loadHotBooks() {
    try {
        const response = await fetch(`${API_BASE}/books/hot`);
        const result = await response.json();
        
        if (result.code === 200) {
            const container = document.getElementById('hotBooks');
            container.innerHTML = result.data.map(book => createBookCard(book)).join('');
        }
    } catch (error) {
        console.error('加载热门图书失败:', error);
    }
}

async function loadNewBooks() {
    try {
        const response = await fetch(`${API_BASE}/books/new`);
        const result = await response.json();
        
        if (result.code === 200) {
            const container = document.getElementById('newBooks');
            container.innerHTML = result.data.map(book => createBookCard(book)).join('');
        }
    } catch (error) {
        console.error('加载新书失败:', error);
    }
}

function createBookCard(book) {
    return `
        <div class="book-card" onclick="viewBookDetail(${book.id})">
            <div class="book-cover">
                ${book.coverImage ? `<img src="${book.coverImage}" alt="${book.bookName}">` : '📖'}
            </div>
            <div class="book-info">
                <div class="book-title">${book.bookName}</div>
                <div class="book-author">作者：${book.author || '未知'}</div>
                <div class="book-publisher">出版社：${book.publisher || '未知'}</div>
                <div class="book-stock">库存：${book.availableStock}/${book.totalStock}</div>
            </div>
        </div>
    `;
}

async function loadAnnouncements() {
    try {
        const response = await fetch(`${API_BASE}/notices`);
        const result = await response.json();
        
        const container = document.getElementById('announcementList');
        
        if (result.code === 200 && result.data && result.data.length > 0) {
            // 只显示前5条公告
            const notices = result.data.slice(0, 5);
            
            container.innerHTML = notices.map(notice => `
                <div class="announcement-item">
                    ${notice.isTop === 1 ? '<span class="badge-top">置顶</span>' : ''}
                    <h4>${notice.title}</h4>
                    <p>${notice.content.substring(0, 100)}${notice.content.length > 100 ? '...' : ''}</p>
                    <div class="announcement-meta">
                        <span>发布时间：${formatDateTime(notice.publishTime)}</span>
                    </div>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<p style="text-align:center;padding:20px;color:#999;">暂无公告</p>';
        }
    } catch (error) {
        console.error('加载公告失败:', error);
        const container = document.getElementById('announcementList');
        container.innerHTML = '<p style="text-align:center;padding:20px;color:#999;">暂无公告</p>';
    }
}

function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function searchBooks() {
    const keyword = document.getElementById('searchInput').value;
    window.location.href = `/books.html?keyword=${encodeURIComponent(keyword)}`;
}

function viewBookDetail(bookId) {
    window.location.href = `/book-detail.html?id=${bookId}`;
}
