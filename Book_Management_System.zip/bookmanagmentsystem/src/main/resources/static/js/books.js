let currentPage = 1;
let totalPages = 1;
const pageSize = 12;

document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
    
    const urlParams = new URLSearchParams(window.location.search);
    const keyword = urlParams.get('keyword');
    
    if (keyword) {
        document.getElementById('keyword').value = keyword;
    }
    
    loadCategories();
    loadBooks();
});

async function loadCategories() {
    try {
        const response = await fetch('/api/categories');
        const result = await response.json();
        
        if (result.code === 200 && result.data) {
            const select = document.getElementById('categoryFilter');
            
            result.data.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id;
                option.textContent = category.categoryName;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('加载分类失败:', error);
    }
}

function checkLoginStatus() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    
    if (userInfo && userInfo.token) {
        const loginLink = document.getElementById('loginLink');
        const registerLink = document.getElementById('registerLink');
        
        if (loginLink) loginLink.style.display = 'none';
        if (registerLink) registerLink.style.display = 'none';
        
        const avatarMenu = document.getElementById('userAvatarMenu');
        if (avatarMenu) {
            avatarMenu.style.display = 'block';
            
            const avatarImg = document.getElementById('navUserAvatar');
            if (userInfo.avatar) {
                avatarImg.src = userInfo.avatar;
            } else {
                avatarImg.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23667eea" width="100" height="100"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="40">👤</text></svg>';
            }
            
            avatarImg.title = userInfo.realName || userInfo.username;
        }
    }
}

function goToDashboard() {
    window.location.href = '/dashboard.html';
}

async function loadBooks() {
    const keyword = document.getElementById('keyword').value;
    const categoryId = document.getElementById('categoryFilter').value;

    let url = `/api/books?pageNum=${currentPage}&pageSize=${pageSize}`;
    if (keyword) url += `&keyword=${encodeURIComponent(keyword)}`;
    if (categoryId) url += `&categoryId=${categoryId}`;

    try {
        const response = await fetch(url);
        const result = await response.json();

        if (result.code === 200) {
            const container = document.getElementById('booksList');

            if (result.data.records.length === 0) {
                container.innerHTML = '<p style="text-align:center;padding:40px;">暂无图书</p>';
            } else {
                container.innerHTML = result.data.records.map(book => createBookCard(book)).join('');
            }

            totalPages = result.data.pages || 1;
            document.getElementById('pageInfo').textContent = `第 ${result.data.current} / ${totalPages} 页`;
            
            updatePageButtons();
        }
    } catch (error) {
        console.error('加载图书失败:', error);
    }
}

function updatePageButtons() {
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (prevBtn) {
        prevBtn.disabled = currentPage <= 1;
    }
    
    if (nextBtn) {
        nextBtn.disabled = currentPage >= totalPages;
    }
}

function createBookCard(book) {
    return `
        <div class="book-card" onclick="viewBookDetail(${book.id})">
            <div class="book-cover">
                ${book.coverImage ? `<img src="${book.coverImage}" alt="${book.bookName}">` : '📖'}
            </div>
            <div class="book-info">
                <div class="book-title">${book.bookName}</div>
                <div class="book-author">作者：${book.author || '未知'}</div>
                <div class="book-publisher">出版社：${book.publisher || '未知'}</div>
                <div class="book-stock">库存：${book.availableStock}/${book.totalStock}</div>
            </div>
        </div>
    `;
}

function viewBookDetail(bookId) {
    window.location.href = `/book-detail.html?id=${bookId}`;
}

function searchBooks() {
    currentPage = 1;
    loadBooks();
}

function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        loadBooks();
    }
}

function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        loadBooks();
    }
}
